#include <SFML/Graphics.hpp>
#include <iostream>
#include <pthread.h>

using namespace std;
using namespace sf;

const int MAP_WIDTH = 28;
const int MAP_HEIGHT = 36;
const int CELL_SIZE = 25;
const int numberOfPellets = 234;
const int numberOfWalls = 422;
int pelletPositionX[numberOfPellets];
int pelletPositionY[numberOfPellets];
int pelletX = 0;
int pelletY = 0;
int tracker = 0;
bool drawPellets[numberOfPellets];
bool setPellet = false;
bool setPowerPellet = false;
bool printingPellets = true;
RectangleShape pellets[numberOfPellets];
RectangleShape walls[numberOfWalls];
int lives;
int score = 0;
int highScore;
Font pacmanFont;
Font pixelFont;
Font scoreFont;
Text scoreText;
Texture logoTexture;
Sprite logo;
Text highScoreText;
const int numberOfPowerPellets = 4;
CircleShape powerPellets[numberOfPowerPellets];
bool powerPelletsEaten[numberOfPowerPellets];
bool powerPelletCollected;
bool loopEntered = true;
float movementSpeed = 0.2f;
float timer = 0; 

Texture life1Texture;
Texture life2Texture;
Texture life3Texture;
Sprite life1;
Sprite life2;
Sprite life3;

//Clock powerPelletClock; // Create the clock instance

int pacmanMaze[MAP_HEIGHT][MAP_WIDTH] = 
{
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1},
    {1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 1, 0, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 3, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1},
    {1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}
};

void setPellets()
{
  for (int i = 0; i < numberOfPellets; i++)
  {
    drawPellets[i] = true;
  }
  
  for (int i = 0; i < numberOfPellets; i++)
  {
    pellets[i].setSize(Vector2f(4, 4));
    pellets[i].setFillColor(Color::White);
  }
}

void setPowerPellets()
{
  for (int i = 0; i < numberOfPowerPellets; i++)
  {
    powerPelletsEaten[i] = false;
  }
  
  for (int i = 0; i < numberOfPowerPellets; i++)
  {
    powerPellets[i].setRadius(9.0f);
    powerPellets[i].setFillColor(Color(128, 128, 128));
  }
}

bool isIntersecting(const Sprite& player, const RectangleShape& pellet)
{
    return player.getGlobalBounds().intersects(pellet.getGlobalBounds());
}

bool isIntersecting(const Sprite& player, const CircleShape& pellet)
{
    return player.getGlobalBounds().intersects(pellet.getGlobalBounds());
}

bool collidingWithPowerPellet(const Sprite& player, const CircleShape& powerPellet)
{
    return player.getGlobalBounds().intersects(powerPellet.getGlobalBounds());
}

void drawMap(RenderWindow& window, Sprite& player)
{
    RectangleShape blank(Vector2f(CELL_SIZE, CELL_SIZE));
    blank.setFillColor(Color::Black);
    
    int count = 0;
    int index = 0;
    int powerCount = 0;
    
    for (int i = 0; i < numberOfWalls; i++)
    {
        walls[i].setSize(Vector2f(CELL_SIZE, CELL_SIZE));
        walls[i].setFillColor(Color::Blue);
    }

    for (int i = 0; i < MAP_HEIGHT; ++i)
    {
        for (int j = 0; j < MAP_WIDTH; ++j)
        {
            if (pacmanMaze[i][j] == 1)
            {
                walls[count].setPosition(j * CELL_SIZE, i * CELL_SIZE);
                window.draw(walls[count]);
                count++;
                
            }
            else if (pacmanMaze[i][j] == 0)
            {
                if (drawPellets[index] == true)
                {
                  pellets[index].setPosition(pelletPositionX[index], pelletPositionY[index]);
                  
                  if (tracker < numberOfPellets)
                  {
                    pelletPositionX[tracker] = j * CELL_SIZE + CELL_SIZE / 2 - 2;
                    pelletPositionY[tracker] = i * CELL_SIZE + CELL_SIZE / 2 - 2;
                  }
                  window.draw(pellets[index]);
                  tracker++;
                  index++;
                }
            }
            else if (pacmanMaze[i][j] == 2)
            {
                blank.setPosition(j * CELL_SIZE + CELL_SIZE / 2 - 2, i * CELL_SIZE + CELL_SIZE / 2 - 2);
                window.draw(blank);
            }
            
            else if (pacmanMaze[i][j] == 3)
            {
                if (powerPelletsEaten[powerCount] == false)
                {
                  powerPellets[powerCount].setPosition(j * CELL_SIZE + CELL_SIZE / 2 - 2, i * CELL_SIZE + CELL_SIZE / 2 - 2);
                  powerPellets[powerCount].setPosition(powerPellets[powerCount].getPosition().x - 5, powerPellets[powerCount].getPosition().y - 7.5f);
                  window.draw(powerPellets[powerCount]);
                }
                powerCount++;
            }
        }
    }
}

void powerPelletCheck(float& movementSpeed, Clock& clock)
{
    static float actionInterval = 10.0f; // Perform action every 5 seconds
    static bool resetClock = true;
    movementSpeed = 0.4f;
    float elapsedTime = 0;

    //cout << movementSpeed << endl; 

    // Get elapsed time in seconds
    elapsedTime = clock.getElapsedTime().asSeconds();

    cout << elapsedTime << endl;

    // Check if the action interval has passed
    if (elapsedTime >= actionInterval)
    {
        movementSpeed = 0.2f; // Change movement speed 

        // Reset the clock and elapsed time
        //clock.restart();
        //resetClock = true;
        powerPelletCollected = false;
    }
    else if (resetClock)
    {
        // Reset the clock only once after the interval has passed
        clock.restart();
        resetClock = false;
    }
}



void PlayerMove(Sprite& player, RenderWindow& window) 
{ 
    RectangleShape blank(Vector2f(CELL_SIZE, CELL_SIZE));
    blank.setFillColor(Color::Black);
    
    cout << movementSpeed << endl; 
    
    for (int i = 0; i < numberOfPowerPellets; i++)
    {
      if (isIntersecting(player, powerPellets[i]))
      {
        if (powerPelletsEaten[i] == false && !powerPelletCollected)
        {
          score += 5;
          scoreText.setString("score: " + to_string(score));
          powerPellets[i].setFillColor(Color::Black); 
          powerPelletsEaten[i] = true;
          powerPelletCollected = true; 
          loopEntered = true;
          break;
        }
      }
    }
    
    //if (powerPelletCollected)
    //{
      //powerPelletCheck(movementSpeed, powerPelletClock);
    //}
    
    //cout << movementSpeed << endl;
    
    for (int i = 0; i < numberOfPellets; i++)
    {
      if (isIntersecting(player, pellets[i]))
      { 
        for (int j = 0; j < numberOfPellets; j++)
        {
          if (pellets[i].getPosition().x == pelletPositionX[j] && pellets[i].getPosition().y == pelletPositionY[j])
          {
            pelletPositionX[j] = -1000;
            pelletPositionY[j] = -1000;
            break;
          }
        }
        
        score += 1;
        scoreText.setString("score: " + to_string(score)); 
        break;
      }    
    }

    if (Keyboard::isKeyPressed(Keyboard::Left))
    {
        player.move(-movementSpeed, 0);
        for (int i = 0; i < numberOfWalls; i++)
        {
          if (isIntersecting(player, walls[i]))
          {
	    player.move(movementSpeed, 0);
          }
        }
    }
    if (Keyboard::isKeyPressed(Keyboard::Right))
    {
        player.move(movementSpeed, 0);
        for (int i = 0; i < numberOfWalls; i++)
        {
          if (isIntersecting(player, walls[i]))
          {
	    player.move(-movementSpeed, 0);
          }
        }
    }
    if (Keyboard::isKeyPressed(Keyboard::Up))
    {
        player.move(0, -movementSpeed);
        for (int i = 0; i < numberOfWalls; i++)
        {
          if (isIntersecting(player, walls[i]))
          {
	    player.move(0, movementSpeed);
          }
        }
    }
    if (Keyboard::isKeyPressed(Keyboard::Down))
    {
        player.move(0, movementSpeed);
        for (int i = 0; i < numberOfWalls; i++)
        {
          if (isIntersecting(player, walls[i]))
          {
	    player.move(0, -movementSpeed);
          }
        }
    }
}


void* StartGame(void* arg)
{
    lives = 3;
    powerPelletCollected = false;
    int gameState = 0;
    int select = 0;
    Clock clock;

    RenderWindow window(VideoMode(MAP_WIDTH * CELL_SIZE, MAP_HEIGHT * CELL_SIZE), "Pac-Man Game"); // 700 x 900
    
    Texture playerTexture;
    if (!playerTexture.loadFromFile("Graphics/player.png"))
    {
        cout << "Could not load player sprite" << endl;
    }
    
    Sprite player(playerTexture);
    player.setPosition(100, 450);
    player.setScale(0.045, 0.045);
    
    Texture redTexture;
    Texture pinkTexture;
    Texture greenTexture;
    Texture blueTexture;
    
    if (!redTexture.loadFromFile("Graphics/Red Enemy.png"))
    {
        cout << "Red Enemy not loaded correctly" << endl;
    }
    
    if (!pinkTexture.loadFromFile("Graphics/Pink Enemy.png"))
    {
        cout << "Pink Enemy not loaded correctly" << endl;
    }

    
    if (!greenTexture.loadFromFile("Graphics/Green Enemy.png"))
    {
        cout << "Green Enemy not loaded correctly" << endl;
    }
    
    if (!blueTexture.loadFromFile("Graphics/Blue Enemy.png"))
    {
        cout << "Blue Enemy not loaded correctly" << endl;
    }
    
    Sprite redEmemy(redTexture);
    redEmemy.setPosition(300, 450);
    redEmemy.setScale(0.25, 0.25);
    
    Sprite pinkEnemy(pinkTexture);
    pinkEnemy.setPosition(325, 450);
    pinkEnemy.setScale(0.25, 0.25);
    
    Sprite greenEmemy(greenTexture);
    greenEmemy.setPosition(350, 450);
    greenEmemy.setScale(0.25, 0.25);
    
    Sprite blueEmemy(blueTexture);
    blueEmemy.setPosition(375, 450);
    blueEmemy.setScale(0.25, 0.25);
    

    if (!setPellet)
    {
      setPellets();
      setPellet = true; 
    }
    
    if (!setPowerPellet)
    {
      setPowerPellets();
      setPowerPellet = true;
    }

    Text playText;
    Text helpText;
    Text exitText;
  
    playText.setFont(pixelFont);
    playText.setCharacterSize(30);
    playText.setFillColor(Color::Green);
    playText.setPosition(300, 300);
    playText.setString("PLAY");
    
    helpText.setFont(pixelFont);
    helpText.setCharacterSize(30);
    helpText.setFillColor(Color::Green);
    helpText.setPosition(300, 400);
    helpText.setString("HELP");
  
    exitText.setFont(pixelFont);
    exitText.setCharacterSize(30);
    exitText.setFillColor(Color::Green);
    exitText.setPosition(300, 500);
    exitText.setString("EXIT");

    if (!logoTexture.loadFromFile("Graphics/Logo"))
    {
      cout << "Logo not loaded correctly" << endl;
    }

    Sprite menuLogo;
    menuLogo.setTexture(logoTexture);
    menuLogo.setScale(0.075, 0.075);
    menuLogo.setPosition(200, 0);
    
    Sprite arrow;
    Texture arrowTexture;
    
    if (!arrowTexture.loadFromFile("Graphics/Arrow 3.png"))
    {
      cout << "Arrow not loaded correctly" << endl;
    }
    
    arrow.setTexture(arrowTexture);
    arrow.setScale(0.1, 0.1);
    arrow.setPosition(225, 290);
    
    
    while (window.isOpen())
    {
    
      float time = clock.getElapsedTime().asSeconds(); 
      clock.restart();
      
      if (powerPelletCollected)
      {
        movementSpeed = 0.4;
        timer += time;
        if (timer >= 5)
        {
          movementSpeed = 0.2;
          timer = 0;
          powerPelletCollected = false;
        }
      }
    
      if (gameState == 0)
      {
        if (select == 0)
        {
          arrow.setPosition(225, 290);
        }
        else if (select == 1)
        {
          arrow.setPosition(225, 390);
        }
        else if (select == 2)
        {
          arrow.setPosition(225, 490);
        }
      
        Event selectController;
        while (window.pollEvent(selectController))
        {

          if (selectController.type == Event::KeyPressed)
          {
            if (selectController.key.code == Keyboard::Up)
            {
              if (select == 1)
              {
                select = 0;
              }
              else if (select == 2)
              {
                select = 1;
              }
            }
            
            if (selectController.key.code == Keyboard::Down)
            {
              if (select == 0)
              {
                select = 1;
              }
              else if (select == 1)
              {
                select = 2;
              }
            }
            
            if (selectController.key.code == Keyboard::Enter)
            {
              if (select == 0)
              {
                gameState = 1;
              }
              else if (select == 1)
              {
                gameState = 2;
              }
              else if (select == 2)
              {
                window.close();
              }
            }
          }
        }
      
        window.clear(Color::Black);
      
        window.draw(playText);
        window.draw(helpText);
        window.draw(exitText);
        window.draw(menuLogo);
        window.draw(arrow);
        
        window.display();
      }
      else if (gameState == 1)
      {
        Event event;
        while (window.pollEvent(event))
        {
          if (event.type == Event::Closed)
            window.close();
        }

	PlayerMove(player, window);

        window.clear(Color::Black);

        drawMap(window, player);
        window.draw(player);
        window.draw(redEmemy);
        window.draw(pinkEnemy);
        window.draw(greenEmemy);
        window.draw(blueEmemy);
        window.draw(scoreText);
        window.draw(highScoreText);
        window.draw(logo);
        window.draw(life1);
        window.draw(life2);
        window.draw(life3);
        
        window.display();
      }  
    }
    
    pthread_exit(NULL);
}

void* SetupUI(void* arg)
{  
  if (!scoreFont.loadFromFile("Graphics/ScoreFont.ttf"))
  {
    cout << "Score Font not loaded correctly" << endl;
  }
  
  if (!logoTexture.loadFromFile("Graphics/Logo"))
  {
    cout << "Logo not loaded correctly" << endl;
  }
  
  if (!pacmanFont.loadFromFile("Graphics/pacman.ttf"))
  {
    cout << "Pacman Font not loaded correctly" << endl;
  }
  
  if (!pixelFont.loadFromFile("Graphics/pixel.ttf"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  
  if (!life1Texture.loadFromFile("Graphics/life.png"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  
  if (!life2Texture.loadFromFile("Graphics/life.png"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  
  if (!life3Texture.loadFromFile("Graphics/life.png"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  
  logo.setTexture(logoTexture);
  logo.setScale(0.05, 0.05);
  logo.setPosition(250, -15);
  
  scoreText.setFont(pixelFont);
  scoreText.setCharacterSize(13);
  scoreText.setFillColor(Color::White);
  scoreText.setPosition(30, 25);
  scoreText.setString("score: " + to_string(score));
  
  highScoreText.setFont(pixelFont);
  highScoreText.setCharacterSize(13);
  highScoreText.setFillColor(Color::White);
  highScoreText.setPosition(500, 25);
  highScoreText.setString("high score: " + to_string(highScore));

  
  life1.setTexture(life1Texture);
  life2.setTexture(life2Texture);
  life3.setTexture(life3Texture);
  
  life1.setScale(0.07, 0.07);
  life1.setPosition(50, 840);
  
  life2.setScale(0.07, 0.07);
  life2.setPosition(90, 840);

  life3.setScale(0.07, 0.07); 
  life3.setPosition(130, 840);
  
  pthread_exit(NULL);
}

int main()
{
    pthread_t gameEngineThread;
    pthread_create(&gameEngineThread, NULL, StartGame, NULL);
    
    pthread_t userInterfaceThread;
    pthread_create(&userInterfaceThread, NULL, SetupUI, NULL);

    pthread_exit(NULL);

    return 0;
}

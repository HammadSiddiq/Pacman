#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <pthread.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fstream>
#include <cstring>
#include <semaphore.h>

using namespace std;
using namespace sf;

/////-----Semaphores -----/////

sem_t keys;
sem_t exitPermits;
//sem_t speedBoost;
sem_t powerSem;

pthread_mutex_t speedBoost;

const int MAP_WIDTH = 28;
const int MAP_HEIGHT = 36;
const int CELL_SIZE = 25;

RenderWindow window(VideoMode(MAP_WIDTH * CELL_SIZE, MAP_HEIGHT * CELL_SIZE), "Pac-Man Game"); // 700 x 900

const int numberOfPellets = 234;
const int numberOfWalls = 422;
int pelletPositionX[numberOfPellets];
int pelletPositionY[numberOfPellets];
int tempPelletX[numberOfPellets];
int tempPelletY[numberOfPellets];
int pelletX = 0;
int pelletY = 0;
int tracker = 0;
bool drawPellets[numberOfPellets];
bool setPellet = false;
bool setPowerPellet = false;
bool printingPellets = true;
RectangleShape pellets[numberOfPellets];
RectangleShape walls[numberOfWalls];
int lives;
int score = 0;
int highScore = 0;
Font pacmanFont;
Font pixelFont;
Font scoreFont;
Text scoreText;
Texture logoTexture;
Sprite logo;
Text highScoreText;
const int numberOfPowerPellets = 4;
CircleShape powerPellets[numberOfPowerPellets];
bool powerPelletsEaten[numberOfPowerPellets];
bool powerPelletCollected;
bool loopEntered = true;
float movementSpeed = 0.3f;
float timer = 0;
float ghostTimer = 0;
int pelletNum;
Texture life1Texture;
Texture life2Texture;
Texture life3Texture;
Sprite life1;
Sprite life2;
Sprite life3;
float powerPelletPositionsX[numberOfPowerPellets];
float powerPelletPositionsY[numberOfPowerPellets];
int winCounter;

///// Blue Booleans /////
bool blueUp = true;
bool blueRight = true;
bool blueDown = true;
bool blueBooleans[13];
bool blueBooleansSet = false;
float blueEnemySpeed = 0.003;
void SetBlueBooleans()
{
  for (int i = 0 ; i < 13; i++)
    blueBooleans[i] = true;
    
  blueBooleansSet = true;
}

///// Red Booleans /////
bool redUp = true;
bool redRight = true;
bool redDown = true;
bool redBooleans[13];
bool redBooleansSet = false;
float redEnemySpeed = 0.003; 
void SetRedBooleans() 
{
  for (int i = 0 ; i < 13; i++)
    redBooleans[i] = true;
    
  redBooleansSet = true;
}

///// Pink Booleans /////
bool pinkUp1 = true;
bool pinkUp2 = true;
bool pinkUp3 = true;
bool pinkLeft1 = true;
bool pinkLeft2 = true;
bool pinkBooleans[5];
bool pinkBooleansSet = false;
float pinkEnemySpeed = 0.003; 

void SetPinkBooleans() 
{
  for (int i = 0 ; i < 5; i++)
    pinkBooleans[i] = true;
    
  pinkBooleansSet = true;
}

///// Green Booleans /////
bool greenUp1 = true;
bool greenUp2 = true;
bool greenUp3 = true;
bool greenLeft1 = true;
bool greenLeft2 = true;
bool greenBooleans[5];
bool greenBooleansSet = false;
float greenEnemySpeed = 0.003; 

void SetGreenBooleans()
{
  for (int i = 0 ; i < 5; i++)
    greenBooleans[i] = true;
    
  greenBooleansSet = true;
}

Text helpDescription;
Text gameOverText;
Text gameOverText2; 
Text gameWinText;
Text gameWinText2;
Text gameWinText3;

int gameState = 0;

Sprite redEnemy;
Sprite pinkEnemy;
Sprite greenEnemy;
Sprite blueEnemy;

bool ghostsSet = false;
bool ghostsRespawned = false;
bool correctGhostRestart = false;

Texture redTexture;
Texture pinkTexture;
Texture greenTexture;
Texture blueTexture;

struct ThreadData
{
  Sprite sprite;
};


int numberOfKeys;
int numberOfExitPermits;

bool greenCollided = false;
bool redCollided = false;
bool blueCollided = false;
bool pinkCollided = false;

Texture dangerGhost;

bool bufferKeys[10];
bool bufferPermits[10];

int produced = 0;

Music backgroundMusic;
Music selectSound;
Music clickSound;
Music loseSound;
Music winSound;
Music collectPowerPelletSound;
Music loseLifeSound;
Music eatGhostSound;

bool blueInHouse = true;
bool pinkInHouse = true;

CircleShape powerPellet1;
CircleShape powerPellet2;
CircleShape powerPellet3;
CircleShape powerPellet4;

CircleShape powerPellet5;
CircleShape powerPellet6;
CircleShape powerPellet7;
CircleShape powerPellet8;

bool showPellet1;
bool showPellet2;
bool showPellet3;
bool showPellet4;

bool pellet1Collected;
bool pellet2Collected;
bool pellet3Collected;
bool pellet4Collected;

float pellet1Timer;
float pellet2Timer;
float pellet3Timer;
float pellet4Timer;

float pellet1GetTimer;
float pellet2GetTimer;
float pellet3GetTimer;
float pellet4GetTimer;

Clock pellet1ReleaseClock;
Clock pellet2ReleaseClock;
Clock pellet3ReleaseClock;
Clock pellet4ReleaseClock;

Clock pellet1GetClock;
Clock pellet2GetClock;
Clock pellet3GetClock;
Clock pellet4GetClock;

Clock pelletClock;

float pelletTimer;

float powerPelletSetter;

//////////---------- FUNCTIONS ----------//////////

bool fileExists(const std::string& filename) {
    std::ifstream file(filename);
    return file.good();
}

void createFileIfNotExists(const std::string& filename) {
    if (!fileExists(filename)) {
        std::ofstream file(filename);
        if (file) {
            std::cout << "File created successfully: " << filename << std::endl;
        } else {
            std::cerr << "Error creating file: " << filename << std::endl;
        }
    } else {
        std::cout << "File already exists: " << filename << std::endl;
    }
}

void createHighscoreFile() {
    // Create a new file named "highscore.txt" if not already created
    ofstream file("highscore.txt");
    if (!file.is_open()) {
        cout << "Error creating highscore file!" << endl; 
        return;
    }
    // Write -1 to the file
    file << 0;
    file.close();
}

void getHighScore() 
{
    ifstream readFile("highscore.txt");
    if (!readFile.is_open())
    {
        cout << "Error opening highscore file!" << endl;
        return;
    }
    readFile >> highScore;
    highScoreText.setString("high score: " + to_string(highScore));
    readFile.close();
}

void updateHighscore() 
{
    ifstream readFile("highscore.txt"); 
    if (!readFile.is_open()) 
    {
        cout << "Error opening highscore file!" << endl;
        return;
    }
    readFile >> highScore;
    highScoreText.setString("high score: " + to_string(highScore));

    readFile.close();

    // Compare with the current highscore
    if (score > highScore)
    {
        // Write the new highscore to the file
        ofstream writeFile("highscore.txt");
        if (!writeFile.is_open()) 
        {
            cout << "Error opening highscore file for writing!" << endl;
            return;
        }
        writeFile << score;
        //getHighScore();
        score = 0;
        scoreText.setString("score: " + to_string(score));
        writeFile.close();
        
    }  
}

void Producer()
{
  sem_wait(&keys);
  sem_wait(&exitPermits);
  produced++;
  sem_post(&keys);
  sem_post(&exitPermits);
  
}

void Consumer()
{
  sem_wait(&keys);
  sem_wait(&exitPermits);
  produced--;
  sem_post(&keys);
  sem_post(&exitPermits);
}

void ResetBooleans()
{

  life1.setScale(0.07, 0.07);
  life1.setPosition(50, 840); 
  
  life2.setScale(0.07, 0.07);
  life2.setPosition(90, 840);

  life3.setScale(0.07, 0.07); 
  life3.setPosition(130, 840);

  redEnemy.setPosition(300, 450);
  pinkEnemy.setPosition(325, 450);
  greenEnemy.setPosition(350, 450);
  blueEnemy.setPosition(375, 450);

  blueUp = true;
  blueRight = true;
  blueDown = true;
  
  for(int i = 0; i < 13; i++)
    blueBooleans[i] = true;

  redUp = true;
  redRight = true;
  redDown = true;
  
  for (int i = 0; i < 13; i++)
    redBooleans[i] = true;

  pinkUp1 = true;
  pinkUp2 = true;
  pinkUp3 = true;
  pinkLeft1 = true;
  pinkLeft2 = true;
  
  for (int i = 0; i < 5; i++)
    pinkBooleans[i] = true;

  greenUp1 = true;
  greenUp2 = true;
  greenUp3 = true;
  greenLeft1 = true;
  greenLeft2 = true;
  
  for (int i = 0; i < 5; i++)
    greenBooleans[i] = true;
}

void SetGhosts()
{
    if (!redTexture.loadFromFile("Graphics/Red Enemy.png"))
    {
        cout << "Red Enemy not loaded correctly" << endl;
    }
    
    if (!pinkTexture.loadFromFile("Graphics/Pink Enemy.png"))
    {
        cout << "Pink Enemy not loaded correctly" << endl;
    }

    
    if (!greenTexture.loadFromFile("Graphics/Green Enemy.png"))
    {
        cout << "Green Enemy not loaded correctly" << endl;
    }
    
    if (!blueTexture.loadFromFile("Graphics/Blue Enemy.png"))
    {
        cout << "Blue Enemy not loaded correctly" << endl;
    }

    redEnemy.setTexture(redTexture);
    redEnemy.setPosition(300, 450);
    redEnemy.setScale(0.25, 0.25);
    
    pinkEnemy.setTexture(pinkTexture);
    pinkEnemy.setPosition(325, 450); 
    pinkEnemy.setScale(0.25, 0.25);
    
    greenEnemy.setTexture(greenTexture);
    greenEnemy.setPosition(350, 450);
    greenEnemy.setScale(0.25, 0.25);
    
    blueEnemy.setTexture(blueTexture);
    blueEnemy.setPosition(375, 450); 
    blueEnemy.setScale(0.25, 0.25);
    
    ghostsSet = true;
}

void* GreenEnemyMovement(void* greenGhost)
{

while (true)
{
    


  //sem_post(&keys);
  //sem_post(&exitPermits);
  
  
  
  cout << endl;
  cout << endl;
  bool greenLoopBooleans[5];
  
  for (int i = 0; i < 5; i++)
    greenLoopBooleans[i] = true;
    
    //cout << "D" << endl;
    //cout << greenEnemy.getPosition().x << endl;

  if (!greenBooleansSet)
    SetGreenBooleans();
    
    //cout << "E" << endl;
    //cout << greenEnemy.getPosition().x << endl;
    
  if (greenUp1)
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x, greenEnemy.getPosition().y - greenEnemySpeed);
    if (greenEnemy.getPosition().y <= 350)
    {
      greenUp1 = false;
    }
  }
  
  //cout << "F" << endl;
  //cout << greenEnemy.getPosition().x << endl;
  
  if (greenLeft1 && !greenUp1)
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x + greenEnemySpeed, greenEnemy.getPosition().y);
    if (greenEnemy.getPosition().x >= 400)
    {
      greenLeft1 = false;
    }
  }
  
  //cout << "G" << endl;
  //cout << greenEnemy.getPosition().x << endl;
  
  if (!greenLeft1 && greenUp2)
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x, greenEnemy.getPosition().y - greenEnemySpeed);
    if (greenEnemy.getPosition().y <= 275)
    {
      greenUp2 = false;
    }
  }
  
  //cout << "H" << endl;
  //cout << greenEnemy.getPosition().x << endl;
  
  if (greenLeft2 && !greenUp2)
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x + greenEnemySpeed, greenEnemy.getPosition().y);
    if (greenEnemy.getPosition().x >= 450)
    {
      greenLeft2 = false;
    }
  }
  
  //cout << "I" << endl;
  //cout << greenEnemy.getPosition().x << endl;
  
  if (!greenLeft2 && greenUp3)
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x, greenEnemy.getPosition().y - greenEnemySpeed);
    if (greenEnemy.getPosition().y <= 200)
    {
      greenUp3 = false;
    }
  }
  
   //cout << "J" << endl;
   //cout << greenEnemy.getPosition().x << endl;
  
  /////---------- In Loop ----------//////////
  
  if (greenBooleans[0] && !greenUp3)
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x - greenEnemySpeed, greenEnemy.getPosition().y);
    if (greenEnemy.getPosition().x <= 375)
    {
      greenBooleans[0] = false;
    }
  }
  
  //cout << "K" << endl;
  //cout << greenEnemy.getPosition().x << endl;
  
  if (greenBooleans[1] && !greenBooleans[0])
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x, greenEnemy.getPosition().y - greenEnemySpeed);
    if (greenEnemy.getPosition().y <= 100)
    {
      greenBooleans[1] = false;
    }
  }
  
  //cout << "L" << endl;
  //cout << greenEnemy.getPosition().x << endl;
  
  if (greenBooleans[2] && !greenBooleans[1])
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x + greenEnemySpeed, greenEnemy.getPosition().y);
    if (greenEnemy.getPosition().x >= 650)
    {
      greenBooleans[2] = false;
    }
  }
  
  //cout << "M" << endl;
  //cout << greenEnemy.getPosition().x << endl;
  
  if (greenBooleans[3] && !greenBooleans[2])
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x, greenEnemy.getPosition().y + greenEnemySpeed);
    if (greenEnemy.getPosition().y >= 200)
    {
      greenBooleans[3] = false;
    }
  }
  
  //cout << "N" << endl;
  //cout << greenEnemy.getPosition().x << endl;
  
  if (greenBooleans[4] && !greenBooleans[3])
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x - greenEnemySpeed, greenEnemy.getPosition().y);
    if (greenEnemy.getPosition().x >= 575)
    {
      greenBooleans[4] = false;
      for (int i = 0; i < 5; i++)
      {
        greenBooleans[i] = true;
      }
    }
  }
  
  //cout << "O" << endl;
  //cout << greenEnemy.getPosition().x << endl;
  
  if (ghostTimer >= 5)
  {
    sem_post(&keys);
    sem_post(&exitPermits);
    ghostTimer = 0;
  }

  if (greenCollided)
  {
    greenCollided = false;
    float respawnTimer = 0;

    Clock ghostClock;

  while (respawnTimer <= 3)
  {
    float respawnTime = ghostClock.getElapsedTime().asSeconds();
    ghostClock.restart();

    respawnTimer += respawnTime;
  }



    if (respawnTimer >= 3)
    {
      sem_wait(&keys);
      sem_wait(&exitPermits);

      respawnTimer = 0;
    }

    //pthread_exit(NULL);
  }
  
  
  
}
    
}


int pacmanMaze[MAP_HEIGHT][MAP_WIDTH] = 
{
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1},
    {1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 1, 0, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 3, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1},
    {1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}
};


void* PinkEnemyMovement(void* pinkGhost) // Loop (X = 25, Y = 100, X = 300, Y = 200, X = 225)
{

pinkEnemySpeed = 0.006;

while (true)
{

  //sem_wait(&exitPermits);
  //sem_wait(&keys);
  

  cout << endl;
  cout << endl;
  
  bool pinkLoopBooleans[5];
  
  for (int i = 0; i < 5; i++)
    pinkLoopBooleans[i] = true;

  if (!pinkBooleansSet)
    SetPinkBooleans();
    
  if (pinkUp1)
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x, pinkEnemy.getPosition().y - pinkEnemySpeed);
    if (pinkEnemy.getPosition().y <= 350)
    {
      pinkUp1 = false;
    }
  }
  
  if (pinkLeft1 && !pinkUp1)
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x - pinkEnemySpeed, pinkEnemy.getPosition().y);
    if (pinkEnemy.getPosition().x <= 290)
    {
      pinkLeft1 = false;
    }
  }
  
  if (!pinkLeft1 && pinkUp2)
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x, pinkEnemy.getPosition().y - pinkEnemySpeed);
    if (pinkEnemy.getPosition().y <= 275)
    {
      pinkUp2 = false;
    }
  }
  
  if (pinkLeft2 && !pinkUp2)
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x - pinkEnemySpeed, pinkEnemy.getPosition().y);
    if (pinkEnemy.getPosition().x <= 225)
    {
      pinkLeft2 = false;
    }
  }
  
  if (!pinkLeft2 && pinkUp3)
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x, pinkEnemy.getPosition().y - pinkEnemySpeed);
    if (pinkEnemy.getPosition().y <= 200)
    {
      pinkUp3 = false;
    }
  }
  
  /////---------- In Loop ----------//////////
  
  if (pinkBooleans[0] && !pinkUp3)
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x - pinkEnemySpeed, pinkEnemy.getPosition().y);
    if (pinkEnemy.getPosition().x <= 25)
    {
      pinkBooleans[0] = false;
    }
  }
  
  if (pinkBooleans[1] && !pinkBooleans[0])
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x, pinkEnemy.getPosition().y - pinkEnemySpeed);
    if (pinkEnemy.getPosition().y <= 100)
    {
      pinkBooleans[1] = false;
    }
  }
  
  if (pinkBooleans[2] && !pinkBooleans[1])
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x + pinkEnemySpeed, pinkEnemy.getPosition().y);
    if (pinkEnemy.getPosition().x >= 300)
    {
      pinkBooleans[2] = false;
    }
  }
  
  if (pinkBooleans[3] && !pinkBooleans[2])
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x, pinkEnemy.getPosition().y + pinkEnemySpeed);
    if (pinkEnemy.getPosition().y >= 200)
    {
      pinkBooleans[3] = false;
    }
  }
  
  if (pinkBooleans[4] && !pinkBooleans[3])
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x - pinkEnemySpeed, pinkEnemy.getPosition().y);
    if (pinkEnemy.getPosition().x >= 225)
    {
      pinkBooleans[4] = false;
      for (int i = 0; i < 5; i++)
      {
        pinkBooleans[i] = true;
      }
    }
  }
  
  if (ghostTimer >= 5)
  {
    sem_post(&keys);
    sem_post(&exitPermits);
    ghostTimer = 0;
  }

  if (pinkCollided)
  {
    pinkInHouse = true;
    pinkCollided = false;
    float respawnTimer = 0;

    Clock ghostClock;

  while (respawnTimer <= 3)
  {
    float respawnTime = ghostClock.getElapsedTime().asSeconds();
    ghostClock.restart();

    respawnTimer += respawnTime;
  }



    if (respawnTimer >= 3)
    {
      sem_wait(&keys);
      sem_wait(&exitPermits);
      pinkInHouse = false;
      if (blueEnemySpeed == 0.003)
      {
        pinkEnemySpeed = 0.006;
      }
      respawnTimer = 0;
    }

    //pthread_exit(NULL);
  }
  

 
}

   pthread_exit(NULL);
}
void* RedEnemyMovement(void* redGhost)
{

while (true)
{
  
  //sem_wait(&keys);
  //sem_wait(&exitPermits);
  
  cout << endl;
  cout << endl;
  
  bool movingUp = true;
  bool movingRight = true;
  bool movingDown = true;
  
  bool redLoopBooleans[13];
  
  for (int i = 0; i < 13; i++)
    redLoopBooleans[i] = true;

  if (!redBooleansSet)
    SetRedBooleans();
  
  if (movingUp && redUp)
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y - redEnemySpeed);
    if (redEnemy.getPosition().y <= 360)
    {
      movingUp = false;
      redUp = false;
    }
  }
  
  if (!redUp && movingRight && redRight)
  {
    redEnemy.setPosition(redEnemy.getPosition().x - redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x <= 210)
    {
      movingRight = false;
      redRight = false;
    }
  }
  
  if (!redRight && movingDown && redDown)
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y + redEnemySpeed);
    if (redEnemy.getPosition().y >= 600)
    {
      movingDown = false;
      redDown = false;
    }
  }
  
/////---------- Loop Coding ----------/////
  
  if (!redDown && redLoopBooleans[0] && redBooleans[0])
  {
    redEnemy.setPosition(redEnemy.getPosition().x + redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x >= 300)
    {
      redBooleans[0] = false;
    }
  }
  
  if (!redBooleans[0] && redLoopBooleans[1] && redBooleans[1])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y + redEnemySpeed);
    if (redEnemy.getPosition().y >= 650)
    {
      redBooleans[1] = false;
    }
  }
  
  if (!redBooleans[1] && redLoopBooleans[2] && redBooleans[2])
  {
    redEnemy.setPosition(redEnemy.getPosition().x - redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x <= 225)
    {
      redBooleans[2] = false;
    }
  }
  
  if (!redBooleans[2] && redLoopBooleans[3] && redBooleans[3])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y + redEnemySpeed);
    if (redEnemy.getPosition().y >= 700)
    {
      redBooleans[3] = false;
    }
  }
  
  if (!redBooleans[3] && redLoopBooleans[4] && redBooleans[4])
  {
    redEnemy.setPosition(redEnemy.getPosition().x + redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x >= 300)
    {
      redBooleans[4] = false;
    }
  }
  
  if (!redBooleans[4] && redLoopBooleans[5] && redBooleans[5])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y + redEnemySpeed);
    if (redEnemy.getPosition().y >= 775)
    {
      redBooleans[5] = false;
    }
  }
  
  if (!redBooleans[5] && redLoopBooleans[6] && redBooleans[6])
  {
    redEnemy.setPosition(redEnemy.getPosition().x - redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x <= 25)
    {
      redBooleans[6] = false;
    }
  }
  
  if (!redBooleans[6] && redLoopBooleans[7] && redBooleans[7])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y - redEnemySpeed);
    if (redEnemy.getPosition().y <= 700)
    {
      redBooleans[7] = false;
    }
  }
  
  if (!redBooleans[7] && redLoopBooleans[8] && redBooleans[8])
  {
    redEnemy.setPosition(redEnemy.getPosition().x + redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x >= 75)
    {
      redBooleans[8] = false;
    }
  }
  
  if (!redBooleans[8] && redLoopBooleans[9] && redBooleans[9])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y - redEnemySpeed);
    if (redEnemy.getPosition().y <= 650)
    {
      redBooleans[9] = false;
    }
  }
  
  if (!redBooleans[9] && redLoopBooleans[10] && redBooleans[10])
  {
    redEnemy.setPosition(redEnemy.getPosition().x - redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x <= 25)
    {
      redBooleans[10] = false;
    }
  }
  
  if (!redBooleans[10] && redLoopBooleans[11] && redBooleans[11])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y - redEnemySpeed);
    if (redEnemy.getPosition().y <= 600)
    {
      redBooleans[11] = false;
    }
  }
  
  if (!redBooleans[11] && redLoopBooleans[12] && redBooleans[12])
  {
    redEnemy.setPosition(redEnemy.getPosition().x + redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x >= 110) 
    {
      redBooleans[12] = false;
      for (int i = 0; i < 13; i++)
      {
        redLoopBooleans[i] = true;
        redBooleans[i] = true;
      }
    }
  }

  if (ghostTimer >= 5)
  {
    sem_post(&keys);
    sem_post(&exitPermits);
    ghostTimer = 0;
  }

  if (redCollided)
  {
    redCollided = false;
    float respawnTimer = 0;

    Clock ghostClock;

  while (respawnTimer <= 3)
  {
    float respawnTime = ghostClock.getElapsedTime().asSeconds();
    ghostClock.restart();

    respawnTimer += respawnTime;
  }



    if (respawnTimer >= 3)
    {
      sem_wait(&keys);
      sem_wait(&exitPermits);

      respawnTimer = 0;
    }

    //pthread_exit(NULL);
  }
  


}
    //pthread_exit(NULL);
}

void setPellets()
{
  for (int i = 0; i < numberOfPellets; i++)
  {
    drawPellets[i] = true;
  }
  
  for (int i = 0; i < numberOfPellets; i++)
  {
    pellets[i].setSize(Vector2f(4, 4));
    pellets[i].setFillColor(Color::White);
  }
}

void setPowerPellets() 
{

  powerPellet1.setRadius(9.0f);
  powerPellet1.setFillColor(Color(128, 128, 128));


  powerPellet2.setRadius(9.0f);
  powerPellet2.setFillColor(Color(128, 128, 128));


  powerPellet3.setRadius(9.0f);
  powerPellet3.setFillColor(Color(128, 128, 128));


  powerPellet4.setRadius(9.0f);
  powerPellet4.setFillColor(Color(128, 128, 128));

  powerPellet5.setRadius(9.0f);
  powerPellet5.setFillColor(Color(128, 128, 128));

  powerPellet6.setRadius(9.0f);
  powerPellet6.setFillColor(Color(128, 128, 128));

  powerPellet7.setRadius(9.0f);
  powerPellet7.setFillColor(Color(128, 128, 128));

  powerPellet8.setRadius(9.0f);
  powerPellet8.setFillColor(Color(128, 128, 128));

  showPellet1 = false;
  showPellet2 = false;
  showPellet3 = false;
  showPellet4 = false;

  pellet1Collected = false;
  pellet2Collected = false;
  pellet3Collected = false;
  pellet4Collected = false;


  for (int i = 0; i < numberOfPowerPellets; i++)
  {
    powerPelletsEaten[i] = true;
  }
  
  for (int i = 0; i < numberOfPowerPellets; i++)
  {
    powerPellets[i].setRadius(9.0f);
    powerPellets[i].setFillColor(Color(128, 128, 128));
  }
}

bool isIntersecting(const Sprite& player, const RectangleShape& pellet)
{
    return player.getGlobalBounds().intersects(pellet.getGlobalBounds());
}

bool isIntersecting(const Sprite& player, const CircleShape& pellet)
{
    return player.getGlobalBounds().intersects(pellet.getGlobalBounds());
}

bool collidingWithPowerPellet(const Sprite& player, const CircleShape& powerPellet)
{
    return player.getGlobalBounds().intersects(powerPellet.getGlobalBounds());
}

bool EnemyCollision(const Sprite& player, const Sprite& enemy)
{
  return player.getGlobalBounds().intersects(enemy.getGlobalBounds());
}

// Loop (X = 650, Y = 650, X = 600, Y = 700, X = 650, Y = 775, X = 375, Y = 700, X = 450, Y = 650, X = 375, Y = 600, X = 460) 

void* BlueEnemyMovement(void* blueGhost) 
{

while (true)
{

  //sem_wait(&keys);
  //sem_wait(&exitPermits);

  cout << endl;
  cout << endl;

  bool movingUp = true;
  bool movingRight = true;
  bool movingDown = true;
  
  bool blueLoopBooleans[13];
  
  for (int i = 0; i < 13; i++)
    blueLoopBooleans[i] = true;

  if (!blueBooleansSet)
    SetBlueBooleans();
  
  if (movingUp && blueUp)
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y - blueEnemySpeed);
    if (blueEnemy.getPosition().y <= 360)
    {
      movingUp = false;
      blueUp = false;
    }
  }
  
  if (!blueUp && movingRight && blueRight)
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x >= 460)
    {
      movingRight = false;
      blueRight = false;
    }
  }
  
  if (!blueRight && movingDown && blueDown)
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y + blueEnemySpeed);
    if (blueEnemy.getPosition().y >= 600)
    {
      movingDown = false;
      blueDown = false;
    }
  }
  
/////---------- Loop Coding ----------/////
  
  if (!blueDown && blueLoopBooleans[0] && blueBooleans[0])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x >= 650)
    {
      blueBooleans[0] = false;
    }
  }
  
  if (!blueBooleans[0] && blueLoopBooleans[1] && blueBooleans[1])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y + blueEnemySpeed);
    if (blueEnemy.getPosition().y >= 650)
    {
      blueBooleans[1] = false;
    }
  }
  
  if (!blueBooleans[1] && blueLoopBooleans[2] && blueBooleans[2])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x - blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x <= 600)
    {
      blueBooleans[2] = false;
    }
  }
  
  if (!blueBooleans[2] && blueLoopBooleans[3] && blueBooleans[3])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y + blueEnemySpeed);
    if (blueEnemy.getPosition().y >= 700)
    {
      blueBooleans[3] = false;
    }
  }
  
  if (!blueBooleans[3] && blueLoopBooleans[4] && blueBooleans[4])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x >= 650)
    {
      blueBooleans[4] = false;
    }
  }
  
  if (!blueBooleans[4] && blueLoopBooleans[5] && blueBooleans[5])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y + blueEnemySpeed);
    if (blueEnemy.getPosition().y >= 775)
    {
      blueBooleans[5] = false;
    }
  }
  
  if (!blueBooleans[5] && blueLoopBooleans[6] && blueBooleans[6])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x - blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x <= 375)
    {
      blueBooleans[6] = false;
    }
  }
  
  if (!blueBooleans[6] && blueLoopBooleans[7] && blueBooleans[7])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y - blueEnemySpeed);
    if (blueEnemy.getPosition().y <= 700)
    {
      blueBooleans[7] = false;
    }
  }
  
  if (!blueBooleans[7] && blueLoopBooleans[8] && blueBooleans[8])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x >= 450)
    {
      blueBooleans[8] = false;
    }
  }
  
  if (!blueBooleans[8] && blueLoopBooleans[9] && blueBooleans[9])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y - blueEnemySpeed);
    if (blueEnemy.getPosition().y <= 650)
    {
      blueBooleans[9] = false;
    }
  }
  
  if (!blueBooleans[9] && blueLoopBooleans[10] && blueBooleans[10])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x - blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x <= 375)
    {
      blueBooleans[10] = false;
    }
  }
  
  if (!blueBooleans[10] && blueLoopBooleans[11] && blueBooleans[11])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y - blueEnemySpeed);
    if (blueEnemy.getPosition().y <= 600)
    {
      blueBooleans[11] = false;
    }
  }
  
  if (!blueBooleans[11] && blueLoopBooleans[12] && blueBooleans[12])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x >= 460)
    {
      blueBooleans[12] = false;
      for (int i = 0; i < 13; i++)
      {
        blueLoopBooleans[i] = true;
        blueBooleans[i] = true;
      }
    }
  }
  
  if (ghostTimer >= 5)
  {
    sem_post(&keys);
    sem_post(&exitPermits);
    ghostTimer = 0;
  }

  if (blueCollided && !pinkCollided)
  {
    blueEnemySpeed = 0.003;
    pinkEnemySpeed = 0.006;
  }

  if (blueCollided)
  {
    blueInHouse = true;
    blueCollided = false;
    float respawnTimer = 0;

    Clock ghostClock;

  while (respawnTimer <= 3)
  {
    blueInHouse = false;
    if (pinkEnemySpeed == 0.003)
    {
      blueEnemySpeed = 0.006;
    }
    float respawnTime = ghostClock.getElapsedTime().asSeconds();
    ghostClock.restart();

    respawnTimer += respawnTime;
  }



    if (respawnTimer >= 3)
    {
      sem_wait(&keys);
      sem_wait(&exitPermits);
      respawnTimer = 0;
    }

    //pthread_exit(NULL);
  }
  
}
  pthread_exit(NULL);
}
void drawMap(/*RenderWindow& window,*/ Sprite& player)
{
    int sharedMemoryID;
    void* gameBoard;
    

    if (showPellet1 == true)
    {
      powerPellet1.setPosition(powerPellet5.getPosition().x, powerPellet5.getPosition().y);
      window.draw(powerPellet1);
    }

    if (showPellet2 == true)
    {
      powerPellet2.setPosition(powerPellet6.getPosition().x, powerPellet6.getPosition().y);
      window.draw(powerPellet2);
    }

    if (showPellet3 == true)
    {
      powerPellet3.setPosition(powerPellet7.getPosition().x, powerPellet7.getPosition().y);
      window.draw(powerPellet3);
    }

    if (showPellet4 == true)
    {
      powerPellet4.setPosition(powerPellet8.getPosition().x, powerPellet8.getPosition().y);
      window.draw(powerPellet4);
    }

    //sharedMemoryID = shmget(1, 1024, 0666);
    //gameBoard = shmat(sharedMemoryID, NULL, 0);

    //int gameMaze[MAP_HEIGHT][MAP_WIDTH];

    //memcpy(gameMaze, gameBoard, MAP_HEIGHT * MAP_WIDTH * sizeof(int));

    RectangleShape blank(Vector2f(CELL_SIZE, CELL_SIZE));
    blank.setFillColor(Color::Black);
    
    int count = 0;
    int index = 0;
    int powerCount = 0;
    
    for (int i = 0; i < numberOfWalls; i++)
    {
        walls[i].setSize(Vector2f(CELL_SIZE, CELL_SIZE));
        walls[i].setFillColor(Color::Blue);
    }

    for (int i = 0; i < MAP_HEIGHT; ++i)
    {
        for (int j = 0; j < MAP_WIDTH; ++j)
        {
            if (pacmanMaze[i][j] == 1)
            {
                walls[count].setPosition(j * CELL_SIZE, i * CELL_SIZE);
                window.draw(walls[count]);
                count++;
                
            }
            else if (pacmanMaze[i][j] == 0)
            {
                if (drawPellets[index] == true)
                {
                  pellets[index].setPosition(pelletPositionX[index], pelletPositionY[index]);
                  
                  if (tracker < numberOfPellets)
                  {
                    pelletPositionX[tracker] = j * CELL_SIZE + CELL_SIZE / 2 - 2;
                    pelletPositionY[tracker] = i * CELL_SIZE + CELL_SIZE / 2 - 2;
                    tempPelletX[tracker] = j * CELL_SIZE + CELL_SIZE / 2 - 2;
                    tempPelletY[tracker] = i * CELL_SIZE + CELL_SIZE / 2 - 2;
                  }
                  window.draw(pellets[index]);
                  if (tracker != numberOfPellets)
                    tracker++;

                  index++;
                }
            }
            else if (pacmanMaze[i][j] == 2)
            {
                blank.setPosition(j * CELL_SIZE + CELL_SIZE / 2 - 2, i * CELL_SIZE + CELL_SIZE / 2 - 2);
                window.draw(blank);
            }
            
            else if (pacmanMaze[i][j] == 3)
            {


                //if (powerPelletsEaten[powerCount] == false)
                //{
                  powerPellets[powerCount].setPosition(j * CELL_SIZE + CELL_SIZE / 2 - 2, i * CELL_SIZE + CELL_SIZE / 2 - 2);
                  powerPellets[powerCount].setPosition(powerPellets[powerCount].getPosition().x - 5, powerPellets[powerCount].getPosition().y - 7.5f);
                  powerPelletPositionsX[powerCount] = powerPellets[powerCount].getPosition().x;
                  powerPelletPositionsY[powerCount] = powerPellets[powerCount].getPosition().y;

                  //window.draw(powerPellets[powerCount]);
                //}

                if (powerPelletSetter < 4)
                {
                  if (powerCount == 0)
                  {
                    powerPellet5.setPosition(powerPelletPositionsX[powerCount], powerPelletPositionsY[powerCount]);
                  }

                  if (powerCount == 1)
                  {
                    powerPellet6.setPosition(powerPelletPositionsX[powerCount], powerPelletPositionsY[powerCount]);
                  }

                  if (powerCount == 2)
                  {
                    powerPellet7.setPosition(powerPelletPositionsX[powerCount], powerPelletPositionsY[powerCount]);
                  }

                  if (powerCount == 3)
                  {
                    powerPellet8.setPosition(powerPelletPositionsX[powerCount], powerPelletPositionsY[powerCount]);
                  }
                  powerPelletSetter++;

                }
                powerCount++;



            }
        }
    }
}

/*
void powerPelletCheck(float& movementSpeed, Clock& clock)
{
    static float actionInterval = 10.0f; // Perform action every 5 seconds
    static bool resetClock = true;
    movementSpeed = 0.4f;
    float elapsedTime = 0;



    //cout << movementSpeed << endl; 

    // Get elapsed time in seconds
    elapsedTime = clock.getElapsedTime().asSeconds();

    cout << elapsedTime << endl;

    // Check if the action interval has passed
    if (elapsedTime >= actionInterval)
    {
        movementSpeed = 0.2f; // Change movement speed 

        // Reset the clock and elapsed time
        //clock.restart();
        //resetClock = true;
        powerPelletCollected = false;
        

    }
    else if (resetClock)
    {
        // Reset the clock only once after the interval has passed
        clock.restart();
        resetClock = false;
    }
}
*/


void PlayerMove(Sprite& player, /*RenderWindow& window,*/ Sprite& redEnemy, Sprite& pinkEnemy, Sprite& greenEnemy, Sprite& blueEnemy)
{
  
    RectangleShape blank(Vector2f(CELL_SIZE, CELL_SIZE));
    blank.setFillColor(Color::Black);
    
    //cout << movementSpeed << endl; 
    

    if (isIntersecting(player, powerPellet1))
    {
      if (!powerPelletCollected)
      {
          collectPowerPelletSound.openFromFile("Audio/CollectPellet.ogg");
          pellet1Collected = true;
          collectPowerPelletSound.play();
          score += 3;
          powerPelletCollected = true;
          showPellet1 = false;
      }
    }

    if (isIntersecting(player, powerPellet2))
    {
      if (!powerPelletCollected)
      {
          collectPowerPelletSound.openFromFile("Audio/CollectPellet.ogg");
          pellet2Collected = true;
          collectPowerPelletSound.play();
          score += 3;
          powerPelletCollected = true;
          showPellet2 = false;
      }
    }

    if (isIntersecting(player, powerPellet3))
    {
      if (!powerPelletCollected)
      {
          collectPowerPelletSound.openFromFile("Audio/CollectPellet.ogg");
          pellet3Collected = true;
          collectPowerPelletSound.play();
          score += 3;
          powerPelletCollected = true;
          showPellet3 = false;
      }
    }

    if (isIntersecting(player, powerPellet4))
    {
      if (!powerPelletCollected)
      {
          collectPowerPelletSound.openFromFile("Audio/CollectPellet.ogg");
          pellet4Collected = true;
          collectPowerPelletSound.play();
          score += 3;
          powerPelletCollected = true;
          showPellet4 = false;
      }
    }

/*
    
    for (int i = 0; i < numberOfPowerPellets; i++)
    {
      if (isIntersecting(player, powerPellets[i]))
      {
        if (powerPelletsEaten[i] == false && !powerPelletCollected)
        {

          collectPowerPelletSound.openFromFile("Audio/CollectPellet.ogg");
          collectPowerPelletSound.play();
          score += 3;
          scoreText.setString("score: " + to_string(score));
          powerPellets[i].setFillColor(Color::Black); 
          powerPelletsEaten[i] = true;
          powerPelletCollected = true;
          loopEntered = true;
          pelletNum = i;
          break;
        }
      }
    }
    
*/

    if (!powerPelletCollected)
    {
      if (EnemyCollision(player, redEnemy) || EnemyCollision(player, blueEnemy) || EnemyCollision(player, pinkEnemy) || EnemyCollision(player, greenEnemy))
      {
        if (lives == 3)
        {
          loseLifeSound.openFromFile("Audio/LoseLife.ogg");
          loseLifeSound.play();
          life1.setPosition(-1000, -1000);
        }
        else if (lives == 2)
        {
          loseLifeSound.openFromFile("Audio/LoseLife.ogg");
          loseLifeSound.play();
          life2.setPosition(-1000, -1000);
        }
        else if (lives == 1)
        {
          loseLifeSound.openFromFile("Audio/LoseLife.ogg");
          loseLifeSound.play();
          life3.setPosition(-1000, -1000);
        }
    
        lives--;
        player.setPosition(100, 450);
        //sleep(milliseconds(500));
        
        if (lives <= 0)
        {
          loseSound.openFromFile("Audio/Lose.ogg");
          loseSound.play();
          gameState = 3;
        }
      }
    }
    else
    {
      if (EnemyCollision(player, redEnemy))
      {
        eatGhostSound.openFromFile("Audio/EatGhost.ogg");
        eatGhostSound.play();
        score += 5;
        redEnemy.setPosition(300, 450);
        redUp = true;
        redRight = true;
        redDown = true;
        redCollided = true;
        for (int i = 0; i < 13; i++)
        {
          redBooleans[i] = true;
        }
      }
      
      if (EnemyCollision(player, pinkEnemy))
      {
        eatGhostSound.openFromFile("Audio/EatGhost.ogg");
        eatGhostSound.play();
        score += 5;
        pinkEnemy.setPosition(325, 450);
        pinkUp1 = true;
        pinkUp2 = true;
        pinkUp3 = true;
        pinkLeft1 = true;
        pinkLeft2 = true;
        pinkCollided = true;
        for (int i = 0; i < 5; i++)
          pinkBooleans[i] = true;
        
      }
      
      if (EnemyCollision(player, greenEnemy))
      {
        eatGhostSound.openFromFile("Audio/EatGhost.ogg");
        eatGhostSound.play();
        score += 5;
        greenEnemy.setPosition(350, 450); 
        greenUp1 = true;
        greenUp2 = true;
        greenUp3 = true;
        greenLeft1 = true;
        greenLeft2 = true;
        greenCollided = true;
        for (int i = 0; i < 5; i++)
          greenBooleans[i] = true;
      }
      
      if (EnemyCollision(player, blueEnemy))
      {
        eatGhostSound.openFromFile("Audio/EatGhost.ogg");
        eatGhostSound.play();
        score += 5;
        blueEnemy.setPosition(375, 450);
        blueUp = true;
        blueRight = true;
        blueDown = true;
        blueCollided = true;
        for (int i = 0; i < 13; i++)
          blueBooleans[i] = true;
      }
    }
      
    for (int i = 0; i < numberOfPellets; i++)
    {
      if (isIntersecting(player, pellets[i]))
      { 
        for (int j = 0; j < numberOfPellets; j++)
        {
          if (pellets[i].getPosition().x == pelletPositionX[j] && pellets[i].getPosition().y == pelletPositionY[j])
          {
            pelletPositionX[j] = -1000;
            pelletPositionY[j] = -1000;
            winCounter++;
            

            if (winCounter == numberOfPellets - 4)
            {
              winSound.openFromFile("Audio/Win.ogg");
              winSound.play();
              gameState = 4;
              break;
            }

            break;
          }
        }
        
        score += 1;
        scoreText.setString("score: " + to_string(score)); 
        break;
      }    
    }

    if (Keyboard::isKeyPressed(Keyboard::Left))
    {
        //player.setOrigin(player.getLocalBounds().width / 2, player.getLocalBounds().height / 2);
        //player.setRotation(180);
        player.move(-movementSpeed, 0);
        for (int i = 0; i < numberOfWalls; i++)
        {
          if (isIntersecting(player, walls[i]))
          {
	          player.move(movementSpeed, 0);
          }
        }
    }
    if (Keyboard::isKeyPressed(Keyboard::Right))
    {
        player.move(movementSpeed, 0);
        for (int i = 0; i < numberOfWalls; i++)
        {
          if (isIntersecting(player, walls[i]))
          {
	          player.move(-movementSpeed, 0);
          }
        }
    }
    if (Keyboard::isKeyPressed(Keyboard::Up))
    {
        player.move(0, -movementSpeed);
        for (int i = 0; i < numberOfWalls; i++)
        {
          if (isIntersecting(player, walls[i]))
          {
	          player.move(0, movementSpeed);
          }
        }
    }
    if (Keyboard::isKeyPressed(Keyboard::Down))
    {
        player.move(0, movementSpeed);
        for (int i = 0; i < numberOfWalls; i++)
        {
          if (isIntersecting(player, walls[i]))
          {
	          player.move(0, -movementSpeed);
          }
        }
    }
}


void* StartGame(void* arg)
{

    int sharedMemoryID;
    void* gameBoard;
    
    sharedMemoryID = shmget(1, 1024, 0666|IPC_CREAT);
    gameBoard = shmat(sharedMemoryID, NULL, 0); 

    int pacmanMaze[MAP_HEIGHT][MAP_WIDTH] = 
    {
      {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
      {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
      {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
      {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
      {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
      {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
      {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
      {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
      {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
      {1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1},
      {1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1},
      {1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1},
      {1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1},
      {2, 2, 2, 2, 1, 0, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 0, 1, 2, 2, 2, 2},
      {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
      {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
      {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
      {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2},
      {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 3, 2, 2, 2, 2, 2},
      {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2},
      {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
      {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
      {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
      {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
      {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
      {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
      {1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1},
      {1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1},
      {1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1},
      {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
      {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
      {1, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
      {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
      {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
      {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
      {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}
    };
    
    memcpy(gameBoard, pacmanMaze, MAP_HEIGHT * MAP_WIDTH * sizeof(int));

    lives = 3;
    powerPelletCollected = false;
    //int gameState = 0;
    int select = 0;
    Clock clock;
    
    
    if (!dangerGhost.loadFromFile("Graphics/danger.png"))
    {
        cout << "Could not load danger texture" << endl;
    }
    else
    {
      cout << "Texture loaded correctly" << endl;
    }
    
    Texture playerTexture;
    if (!playerTexture.loadFromFile("Graphics/player.png"))
    {
        cout << "Could not load player sprite" << endl;
    }
    
    Sprite player(playerTexture);
    player.setPosition(100, 450);
    player.setScale(0.045, 0.045);
    //player.setOrigin(player.getLocalBounds().width / 2, player.getLocalBounds().height / 2);

    
    //if (!keysAndPermitsSet)
      //SetupKeysAndPermits();

    if (!setPellet)
    {
      setPellets();
      setPellet = true; 
    }
    
    if (!setPowerPellet)
    {
      setPowerPellets();
      setPowerPellet = true;
    }

    Text playText;
    Text helpText;
    Text exitText;
  
    playText.setFont(pixelFont);
    playText.setCharacterSize(30);
    playText.setFillColor(Color::Green);
    playText.setPosition(300, 300);
    playText.setString("PLAY");
    
    helpText.setFont(pixelFont);
    helpText.setCharacterSize(30);
    helpText.setFillColor(Color::Green);
    helpText.setPosition(300, 400);
    helpText.setString("HELP");
  
    exitText.setFont(pixelFont);
    exitText.setCharacterSize(30);
    exitText.setFillColor(Color::Green);
    exitText.setPosition(300, 500);
    exitText.setString("EXIT");
    
    helpDescription.setFont(pixelFont);
    helpDescription.setCharacterSize(16);
    helpDescription.setFillColor(Color::White);
    helpDescription.setPosition(0, 0);
    helpDescription.setString("\n\n\n Its just as simple as collecting pellets \n\n and dodging ghosts!\n\n\n\n But watch out for the faster ghosts who \n\n might get rid of you even before you \n\n realize!\n\n\n\n But don't worry, there's some good news \n\n too. The power pellets can help you gain \n\n speed  and eat those ghosts \n\n\n\n Have Fun!\n\n\n\n          PRESS ENTER TO GO BACK");
    
    gameOverText.setFont(pixelFont);
    gameOverText.setCharacterSize(25);
    gameOverText.setFillColor(Color::Blue);
    gameOverText.setPosition(200, 350);
    gameOverText.setString("GAME OVER!");
    
    gameOverText2.setFont(pixelFont);
    gameOverText2.setCharacterSize(25);
    gameOverText2.setFillColor(Color::Blue);
    gameOverText2.setPosition(75, 450);
    gameOverText2.setString("BETTER LUCK NEXT TIME");

    
    gameWinText.setFont(pixelFont);
    gameWinText.setCharacterSize(30);
    gameWinText.setFillColor(Color::Blue);
    gameWinText.setPosition(100, 200);
    gameWinText.setString("CONGRATULATIONS!");
    
    gameWinText2.setFont(pixelFont);
    gameWinText2.setCharacterSize(20);
    gameWinText2.setFillColor(Color::Yellow);
    gameWinText2.setPosition(175, 400); 
    gameWinText2.setString("You Won the Game!");
    
    gameWinText3.setFont(pixelFont);
    gameWinText3.setCharacterSize(25);
    gameWinText3.setFillColor(Color::Red);
    gameWinText3.setPosition(175, 600);
    gameWinText3.setString("See You Again!");

    if (!logoTexture.loadFromFile("Graphics/Logo"))
    {
      cout << "Logo not loaded correctly" << endl;
    }

    Sprite menuLogo;
    menuLogo.setTexture(logoTexture);
    menuLogo.setScale(0.075, 0.075);
    menuLogo.setPosition(200, 0);
    
    Sprite arrow;
    Texture arrowTexture;
    
    if (!arrowTexture.loadFromFile("Graphics/Arrow 3.png"))
    {
      cout << "Arrow not loaded correctly" << endl;
    }
    else
    {
      cout << "Arrow loaded correctly" << endl;
    }
    arrow.setTexture(arrowTexture);
    arrow.setScale(0.1, 0.1);
    arrow.setPosition(225, 290);
    
    if(!ghostsSet)
    {
      SetGhosts();
    }
    
    while (window.isOpen())
    {

      float time = clock.getElapsedTime().asSeconds();
      clock.restart();
      int value = 0;
      sem_getvalue(&keys, &value);

      if (value < 2)
      ghostTimer += time;
      
      if (blueInHouse && pinkInHouse)
      {
        pinkEnemySpeed = 0.003;
        blueEnemySpeed = 0.003;
      }

      if (blueInHouse && !pinkInHouse)
      {
        pinkEnemySpeed = 0.006;
        blueEnemySpeed = 0.003;
      }

      if (!blueInHouse && pinkInHouse)
      {
        pinkEnemySpeed = 0.003;
        blueEnemySpeed = 0.006;
      }



      if (powerPelletCollected)
      {
        redEnemy.setTexture(dangerGhost);
        greenEnemy.setTexture(dangerGhost);
        blueEnemy.setTexture(dangerGhost);
        pinkEnemy.setTexture(dangerGhost);
      
        movementSpeed = 0.5;
        timer += time;
        if (timer >= 7)
        {
          movementSpeed = 0.3;
          redEnemy.setTexture(redTexture);
          greenEnemy.setTexture(greenTexture);
          blueEnemy.setTexture(blueTexture);
          pinkEnemy.setTexture(pinkTexture);
          powerPelletsEaten[pelletNum] = false;
          powerPellets[pelletNum].setFillColor(Color(128, 128, 128));
          //window.display();
          //window.draw(powerPellets[pelletNum]);
          timer = 0;
          powerPelletCollected = false;
          

        }
      }
    
      if (gameState == 0)
      {
        lives = 3;
        score = 0;
        ghostsRespawned = false;
      
        if (select == 0)
        {
          arrow.setPosition(225, 290);
        }
        else if (select == 1)
        {
          arrow.setPosition(225, 390);
        }
        else if (select == 2)
        {
          arrow.setPosition(225, 490);
        }
      
        Event selectController;
        while (window.pollEvent(selectController))
        {

          if (selectController.type == Event::KeyPressed)
          {
            if (selectController.key.code == Keyboard::Up)
            {
              if (select == 1)
              {
                selectSound.openFromFile("Audio/Select.ogg");
                selectSound.play();
                select = 0;
              }
              else if (select == 2)
              {
                selectSound.openFromFile("Audio/Select.ogg");
                selectSound.play();
                select = 1;
              }
            }
            
            if (selectController.key.code == Keyboard::Down)
            {
              if (select == 0)
              {
                selectSound.openFromFile("Audio/Select.ogg");
                selectSound.play();
                select = 1;
              }
              else if (select == 1)
              {
                selectSound.openFromFile("Audio/Select.ogg");
                selectSound.play();
                select = 2;
              }
            }
            
            if (selectController.key.code == Keyboard::Enter)
            {
              if (select == 0)
              {
                selectSound.openFromFile("Audio/Select.ogg");
                selectSound.play();
                gameState = 1;
              }
              else if (select == 1)
              {
                selectSound.openFromFile("Audio/Select.ogg");
                selectSound.play();
                gameState = 2; 
              }
              else if (select == 2)
              {
                selectSound.openFromFile("Audio/Select.ogg");
                selectSound.play();
                window.close();
              }
            }
          }
        }
      
        window.clear(Color::Black);
      
        window.draw(playText);
        window.draw(helpText);
        window.draw(exitText);
        window.draw(menuLogo);
        window.draw(arrow);
/*
        if (showPellet1)
        {
          window.draw(powerPellet1);
        }


        if (showPellet2)
        {
          window.draw(powerPellet2);
        }


        if (showPellet3)
        {
          window.draw(powerPellet3);
        }


        if (showPellet4)
        {
          window.draw(powerPellet4);
        }
*/      
        window.display();
      }
      else if (gameState == 1)
      {
        if (!ghostsRespawned)
        {
          ResetBooleans();
          ghostsRespawned = true;
        }
        
      
        //BlueEnemyMovement(blueEnemy);
        //RedEnemyMovement(redEnemy); 
        //PinkEnemyMovement(pinkEnemy); 
        //GreenEnemyMovement(greenEnemy);
      
        Event event;
        while (window.pollEvent(event))
        {
          if (event.type == Event::Closed)
            window.close();
        }

	      PlayerMove(player/*, window*/, redEnemy, pinkEnemy, greenEnemy, blueEnemy);

        window.clear(Color::Black);

        drawMap(/*window,*/ player);
        window.draw(player);
        window.draw(redEnemy);
        window.draw(pinkEnemy);
        window.draw(greenEnemy);
        window.draw(blueEnemy);
        window.draw(scoreText);
        window.draw(highScoreText);
        window.draw(logo);
        window.draw(life1);
        window.draw(life2);
        window.draw(life3);
        
        window.display();
      }
      else if (gameState == 2) // HELP
      {
      
        Event selectController;
        while (window.pollEvent(selectController))
        {
          if (selectController.type == Event::KeyPressed)
          {
            if (selectController.key.code == Keyboard::Enter)
            {
              gameState = 0;
            }
          }
        }
        
        window.clear(Color::Black);
        window.draw(helpDescription); 
        window.display();
      }
      else if (gameState == 3) // Game Over
      {
        updateHighscore();
        score = 0;
        scoreText.setString("score: " + to_string(score));
        player.setPosition(100, 450);
        setPowerPellets();
        lives = 3;
        Event selectController;
        while (window.pollEvent(selectController))
        {
          if (selectController.type == Event::KeyPressed)
          {
            if (selectController.key.code == Keyboard::Enter)
            {
              
              //if (!correctGhostRestart)
              //{
                ResetBooleans();
                //correctGhostRestart = true;
              //}
              
              for (int i = 0; i < numberOfPellets; i++)
              {
                pelletPositionX[i] = tempPelletX[i];
                pelletPositionY[i] = tempPelletY[i];
              }
              //gameState = 1;
            }
          }
        }
      
        window.clear(Color::Black);
        window.draw(gameOverText);
        window.draw(gameOverText2);
        window.display();
      
      }
      else if (gameState == 4) // Game Won
      {
        updateHighscore();
        player.setPosition(100, 450);
        score = 0;
        scoreText.setString("score: " + to_string(score));
        setPowerPellets();
        winCounter = 0;
        lives = 3;
        powerPelletCollected = false;
        for (int i = 0; i < numberOfPellets; i++)
        {
          pelletPositionX[i] = tempPelletX[i];
          pelletPositionY[i] = tempPelletY[i];
        }
      
        Event selectController;
        while (window.pollEvent(selectController))
        {
          if (selectController.type == Event::KeyPressed)
          {
            if (selectController.key.code == Keyboard::Enter)
            {
              //gameState = 0;
            }
          }
        }
      
        window.clear(Color::Black);
        window.draw(gameWinText);
        window.draw(gameWinText2);
        window.draw(gameWinText3);
        window.display();
      }
    }

    pthread_exit(NULL);
}

void* SetupUI(void* arg)
{

  if (!scoreFont.loadFromFile("Graphics/ScoreFont.ttf"))
  {
    cout << "Score Font not loaded correctly" << endl;
  }
  
  if (!logoTexture.loadFromFile("Graphics/Logo"))
  {
    cout << "Logo not loaded correctly" << endl;
  }
  
  if (!pacmanFont.loadFromFile("Graphics/pacman.ttf"))
  {
    cout << "Pacman Font not loaded correctly" << endl;
  }
  
  if (!pixelFont.loadFromFile("Graphics/pixel.ttf"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  
  if (!life1Texture.loadFromFile("Graphics/life.png"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  
  if (!life2Texture.loadFromFile("Graphics/life.png"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  
  if (!life3Texture.loadFromFile("Graphics/life.png"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  
  logo.setTexture(logoTexture);
  logo.setScale(0.05, 0.05);
  logo.setPosition(250, -15);
  
  scoreText.setFont(pixelFont);
  scoreText.setCharacterSize(13);
  scoreText.setFillColor(Color::White);
  scoreText.setPosition(30, 25);
  scoreText.setString("score: " + to_string(score));
  
  highScoreText.setFont(pixelFont);
  highScoreText.setCharacterSize(13);
  highScoreText.setFillColor(Color::White);
  highScoreText.setPosition(470, 25);
  highScoreText.setString("high score: " + to_string(highScore));

  
  life1.setTexture(life1Texture);
  life2.setTexture(life2Texture);
  life3.setTexture(life3Texture);
  
  life1.setScale(0.07, 0.07);
  life1.setPosition(50, 840);
  
  life2.setScale(0.07, 0.07);
  life2.setPosition(90, 840);

  life3.setScale(0.07, 0.07); 
  life3.setPosition(130, 840);
  
  pthread_exit(NULL);
}

/*
void* CreatePowerPellets(void* arg)
{
  //sem_wait(&powerSem);
  //sem_wait(&powerSem);
  
  int index1 = rand() % 4;
  int index2;
  
  while (index2 == index1)
  {
    index2 = rand() % 4;
  }
  
  for (int i = 0; i < 1; i++)
  {
    powerPelletsEaten[index1] = false;
    powerPelletsEaten[index1] = false;
  }
  
  if (powerPelletsEaten[index1] == true) 
  {
    sem_post(&powerSem);
  }
  
  if (powerPelletsEaten[index2] == true) 
  {
    sem_post(&powerSem);
  }
  
  pthread_exit(NULL);
  
}
*/

void* HandlePellet1(void* arg)
{

  
  while (true)
  {
    showPellet1 = true;
    cout << "Bool: " << showPellet1 << endl;
    pellet1ReleaseClock.restart();

    while (pellet1Timer < 3)
    {
      float pelletTime = pellet1ReleaseClock.getElapsedTime().asSeconds();
      pellet1ReleaseClock.restart();
      pellet1Timer += pelletTime;
    }

    if (pellet1Timer >= 3)
    {
      int value = 0;
      sem_getvalue(&powerSem, &value);
      
      if (value < 2)
        sem_post(&powerSem);

      pellet1Timer = 0;
    }

    if (pellet1Collected)
    {

      while (pellet1GetTimer < 2)
      {
        pellet1GetClock.restart();
        float pelletTime = pellet1GetClock.getElapsedTime().asSeconds();
        pellet1GetTimer += pelletTime;
        pellet1GetClock.restart();
      }

      pellet1Collected = false;

    }

    if (pellet1GetTimer >= 2)
    {
      sem_wait(&powerSem);
      pellet1GetTimer = 0;

    }

  }

  pthread_exit(NULL);
}

void* HandlePellet2(void* arg)
{
  while (true)
  {
    showPellet2 = true;
    cout << "Bool: " << showPellet2 << endl;
    pellet2ReleaseClock.restart();

    while (pellet2Timer < 3)
    {
      float pelletTime = pellet2ReleaseClock.getElapsedTime().asSeconds();
      pellet2ReleaseClock.restart();
      pellet2Timer += pelletTime;
    }

    if (pellet2Timer >= 3)
    {
      int value = 0;
      sem_getvalue(&powerSem, &value);
      
      if (value < 2)
        sem_post(&powerSem);

      pellet2Timer = 0;
    }

    if (pellet2Collected)
    {

      while (pellet2GetTimer < 2)
      {
        pellet2GetClock.restart();
        float pelletTime = pellet2GetClock.getElapsedTime().asSeconds();
        pellet2GetTimer += pelletTime;
        pellet2GetClock.restart();
      }

      pellet2Collected = false;

    }

    if (pellet2GetTimer >= 2)
    {
      sem_wait(&powerSem);
      pellet2GetTimer = 0;

    }

  }

  pthread_exit(NULL);
}

void* HandlePellet3(void* arg)
{
  while (true)
  {
    showPellet3 = true;
    cout << "Bool: " << showPellet3 << endl;
    pellet3ReleaseClock.restart();

    while (pellet3Timer < 3)
    {
      float pelletTime = pellet3ReleaseClock.getElapsedTime().asSeconds();
      pellet3ReleaseClock.restart();
      pellet3Timer += pelletTime;
    }

    if (pellet3Timer >= 3)
    {
      int value = 0;
      sem_getvalue(&powerSem, &value);
      
      if (value < 2)
        sem_post(&powerSem);

      pellet3Timer = 0;
    }

    if (pellet3Collected)
    {

      while (pellet3GetTimer < 2)
      {
        pellet3GetClock.restart();
        float pelletTime = pellet3GetClock.getElapsedTime().asSeconds();
        pellet3GetTimer += pelletTime;
        pellet3GetClock.restart();
      }

      pellet3Collected = false;

    }

    if (pellet3GetTimer >= 2)
    {
      sem_wait(&powerSem);
      pellet3GetTimer = 0;

    }

  }

  pthread_exit(NULL);
}

void* HandlePellet4(void* arg)
{
    while (true)
  {
    showPellet4 = true;
    cout << "Bool: " << showPellet4 << endl;
    pellet4ReleaseClock.restart();

    while (pellet4Timer < 3)
    {
      float pelletTime = pellet4ReleaseClock.getElapsedTime().asSeconds();
      pellet4ReleaseClock.restart();
      pellet4Timer += pelletTime;
    }

    if (pellet4Timer >= 3)
    {
      int value = 0;
      sem_getvalue(&powerSem, &value);
      
      if (value < 2)
        sem_post(&powerSem);

      pellet4Timer = 0;
    }

    if (pellet4Collected)
    {

      while (pellet4GetTimer < 2)
      {
        pellet4GetClock.restart();
        float pelletTime = pellet4GetClock.getElapsedTime().asSeconds();
        pellet4GetTimer += pelletTime;
        pellet4GetClock.restart();
      }

      pellet4Collected = false;

    }

    if (pellet4GetTimer >= 2)
    {
      sem_wait(&powerSem);
      pellet4GetTimer = 0;

    }

  }
  pthread_exit(NULL);
}

int main()
{

    string filename = "highscore.txt";
    createFileIfNotExists(filename);
    
    backgroundMusic.openFromFile("Audio/BGM.ogg");
    selectSound.openFromFile("Audio/Select.ogg");
    eatGhostSound.openFromFile("Audio/EatGhost.ogg");
    collectPowerPelletSound.openFromFile("Audio/CollectPellet.ogg");
    loseLifeSound.openFromFile("Audio/LoseLife.ogg");
    loseSound.openFromFile("Audio/Lose.ogg");
    winSound.openFromFile("Audio/Win.ogg");

    backgroundMusic.setVolume(50);
    backgroundMusic.play();
    backgroundMusic.setLoop(true);
    
    pellet1Timer = 0;
    pellet2Timer = 0;
    pellet3Timer = 0;
    pellet4Timer = 0;

    pellet1GetTimer = 0;
    pellet2GetTimer = 0;
    pellet3GetTimer = 0;
    pellet4GetTimer = 0;

    pelletTimer = 0;


    int testScore = 0;
    int readInt = -1;
    int currentScore;



    Sprite* redGhost;
    Sprite* greenGhost;
    Sprite* pinkGhost;
    Sprite* blueGhost;
    Sprite* pacman;
    
    const int totalPowerPellets = 4;
    
    Sprite* powerPelletSprites[totalPowerPellets];
    
    /*
    for (int i = 0; i < totalPowerPellets; i++)
    {
      powerPelletSprites[i]->setRadius(9.0f);
      powerPelletSprites[i]->setFillColor(Color(128, 128, 128));
      powerPelletSprites[i]->setPosition(powerPelletPositionsX[i], powerPelletPositionsY[i]);
    }
    */

    int totalGhosts = 4;
    int value = 0;
    numberOfKeys = 2;
    numberOfExitPermits = 2;
    winCounter = 0;
    
    powerPelletSetter = 0;

    //createHighscoreFile();
    getHighScore();

    sem_init(&keys, 0, 2);
    sem_init(&exitPermits, 0, 2);
    //sem_init(&speedBoost, 0, 1);
    pthread_mutex_init(&speedBoost, NULL);
    sem_init(&powerSem, 0, 2);
    
    sem_getvalue(&keys, &value);
    cout << value << endl;
    
    sem_getvalue(&exitPermits, &value);
    cout << value << endl;

    pthread_t redGhostThread;
    pthread_t greenGhostThread;
    pthread_t pinkGhostThread;
    pthread_t blueGhostThread;

    pthread_t pelletThread1;
    pthread_t pelletThread2;
    pthread_t pelletThread3;
    pthread_t pelletThread4;



    pthread_t gameEngineThread;
    pthread_create(&gameEngineThread, NULL, StartGame, NULL);
    
    pthread_t userInterfaceThread;
    pthread_create(&userInterfaceThread, NULL, SetupUI, NULL);
    
    pthread_t powerPelletThreads[totalPowerPellets];

    /*
    for (int i = 0; i < totalPowerPellets; i++)
    {
      pthread_create(&powerPelletThreads[i], NULL, CreatePowerPellets, NULL);
    }highScore
    */
    
    //pthread_t playerThread;
    //pthread_create(&playerThread, NULL, PlayerMove, static_cast<void*>(pacman));




  
    sem_wait(&keys);
    sem_wait(&exitPermits);
    
    pthread_create(&greenGhostThread, NULL, GreenEnemyMovement, static_cast<void*>(greenGhost));
    
    sem_wait(&keys);
    sem_wait(&exitPermits);
    
    
    pthread_create(&redGhostThread, NULL, RedEnemyMovement, static_cast<void*>(redGhost));
    
    sem_wait(&keys);
    sem_wait(&exitPermits);
    pinkInHouse = false;
    pthread_create(&pinkGhostThread, NULL, PinkEnemyMovement, static_cast<void*>(pinkGhost));
    
    sem_wait(&keys);
    sem_wait(&exitPermits);
    pthread_mutex_lock(&speedBoost);
    blueInHouse = false;
    if (pinkEnemySpeed == 0.003)
    {
      blueEnemySpeed = 0.006;
    }
    pthread_create(&blueGhostThread, NULL, BlueEnemyMovement, static_cast<void*>(blueGhost));
  

    sem_wait(&powerSem);
    pthread_create(&pelletThread1, NULL, HandlePellet1, NULL);

    sem_wait(&powerSem);
    pthread_create(&pelletThread2, NULL, HandlePellet2, NULL);

    sem_wait(&powerSem);
    pthread_create(&pelletThread3, NULL, HandlePellet3, NULL);

    sem_wait(&powerSem);
    pthread_create(&pelletThread4, NULL, HandlePellet4, NULL);


    pthread_exit(NULL);

    return 0;
}
#include <SFML/Graphics.hpp>
#include <iostream>
#include <pthread.h>

using namespace std;
using namespace sf;

const int MAP_WIDTH = 28;
const int MAP_HEIGHT = 30;
const int CELL_SIZE = 32;
const int numberOfPellets = 234;
const int numberOfWalls = 422;
int pelletPositionX[numberOfPellets];
int pelletPositionY[numberOfPellets];
int pelletX = 0;
int pelletY = 0;
bool drawPellets[numberOfPellets];
bool setPellet = false;
bool printingPellets = true;
RectangleShape pellets[numberOfPellets]; 
RectangleShape walls[numberOfWalls];

int pacmanMaze[MAP_HEIGHT][MAP_WIDTH] =
{
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1},
    {1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 1, 0, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1},
    {1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
};

void setPellets()
{
  for (int i = 0; i < numberOfPellets; i++)
  {
    drawPellets[i] = true;
  }
  
  for (int i = 0; i < numberOfPellets; i++)
  {
    pellets[i].setSize(Vector2f(4, 4));
    pellets[i].setFillColor(Color::White);
  }
}

void drawMap(RenderWindow& window, Sprite& player)
{
    RectangleShape blank(Vector2f(CELL_SIZE, CELL_SIZE));
    blank.setFillColor(Color::Black);
    
    int count = 0;
    int index = 0;
    
    for (int i = 0; i < numberOfWalls; i++)
    {
        walls[i].setSize(Vector2f(CELL_SIZE, CELL_SIZE));
        walls[i].setFillColor(Color::Blue);
    }

    for (int i = 0; i < MAP_HEIGHT; ++i)
    {
        for (int j = 0; j < MAP_WIDTH; ++j)
        {
            if (pacmanMaze[i][j] == 1)
            {
                walls[count].setPosition(j * CELL_SIZE, i * CELL_SIZE);
                window.draw(walls[count]);
                count++;
                
            }
            else if (pacmanMaze[i][j] == 0)
            {
                if (drawPellets[index] == true)
                {
                  pellets[index].setPosition(j * CELL_SIZE + CELL_SIZE / 2 - 2, i * CELL_SIZE + CELL_SIZE / 2 - 2);
                  window.draw(pellets[index]);
                  index++;
                }
            }
            else if (pacmanMaze[i][j] == 2)
            {
                blank.setPosition(j * CELL_SIZE + CELL_SIZE / 2 - 2, i * CELL_SIZE + CELL_SIZE / 2 - 2);
                window.draw(blank);
            }
        }
    }
}

void PlayerMove(Sprite& player, RenderWindow& window)
{
    float movementSpeed = 0.2f;
    RectangleShape blank(Vector2f(CELL_SIZE, CELL_SIZE));
    blank.setFillColor(Color::Black);

    if (Keyboard::isKeyPressed(Keyboard::Left))
    {
        player.move(-movementSpeed, 0);
    }
    if (Keyboard::isKeyPressed(Keyboard::Right))
    {
        player.move(movementSpeed, 0);
    }
    if (Keyboard::isKeyPressed(Keyboard::Up))
    {
        player.move(0, -movementSpeed);
    }
    if (Keyboard::isKeyPressed(Keyboard::Down))
    {
        player.move(0, movementSpeed);
    }
}


void* StartGame(void* arg)
{
    RenderWindow window(VideoMode(MAP_WIDTH * CELL_SIZE, MAP_HEIGHT * CELL_SIZE), "Pac-Man Game");
    
    Texture playerTexture;
    if (!playerTexture.loadFromFile("Graphics/player.png"))
    {
        cout << "Could not load player sprite" << endl;
    }
    
    Sprite player(playerTexture);
    player.setPosition(100, 475);
    player.setScale(0.06, 0.06);

    if (!setPellet)
    {
      setPellets();
      setPellet = true;
    }

    while (window.isOpen())
    {
    
        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed)
                window.close();
        }

	PlayerMove(player, window);

        window.clear(Color::Black);

        drawMap(window, player);
        window.draw(player);
        window.display();
    }
    
    pthread_exit(NULL);
}

int main()
{
    pthread_t gameEngineThread;
    pthread_create(&gameEngineThread, NULL, StartGame, NULL);

    pthread_exit(NULL);

    return 0;
}


#include <SFML/Graphics.hpp>
#include <iostream>
#include <pthread.h>

using namespace std;
using namespace sf;

const int MAP_WIDTH = 28;
const int MAP_HEIGHT = 36;
const int CELL_SIZE = 25;
const int numberOfPellets = 234;
const int numberOfWalls = 422;
int pelletPositionX[numberOfPellets];
int pelletPositionY[numberOfPellets];
int tempPelletX[numberOfPellets];
int tempPelletY[numberOfPellets];
int pelletX = 0;
int pelletY = 0;
int tracker = 0;
bool drawPellets[numberOfPellets];
bool setPellet = false;
bool setPowerPellet = false;
bool printingPellets = true;
RectangleShape pellets[numberOfPellets];
RectangleShape walls[numberOfWalls];
int lives;
int score = 0;
int highScore;
Font pacmanFont;
Font pixelFont;
Font scoreFont;
Text scoreText;
Texture logoTexture;
Sprite logo;
Text highScoreText;
const int numberOfPowerPellets = 4;
CircleShape powerPellets[numberOfPowerPellets];
bool powerPelletsEaten[numberOfPowerPellets];
bool powerPelletCollected;
bool loopEntered = true;
float movementSpeed = 0.2f;
float timer = 0; 

Texture life1Texture;
Texture life2Texture;
Texture life3Texture;
Sprite life1;
Sprite life2;
Sprite life3;

///// Blue Booleans /////
bool blueUp = true;
bool blueRight = true;
bool blueDown = true;
bool blueBooleans[13];
bool blueBooleansSet = false;
float blueEnemySpeed = 0.1; 
void SetBlueBooleans()
{
  for (int i = 0 ; i < 13; i++)
    blueBooleans[i] = true;
    
  blueBooleansSet = true;
}

///// Red Booleans /////
bool redUp = true;
bool redRight = true;
bool redDown = true;
bool redBooleans[13];
bool redBooleansSet = false;
float redEnemySpeed = 0.1; 
void SetRedBooleans() 
{
  for (int i = 0 ; i < 13; i++)
    redBooleans[i] = true;
    
  redBooleansSet = true;
}

///// Pink Booleans /////
bool pinkUp1 = true;
bool pinkUp2 = true;
bool pinkUp3 = true;
bool pinkLeft1 = true;
bool pinkLeft2 = true;
bool pinkBooleans[5];
bool pinkBooleansSet = false;
float pinkEnemySpeed = 0.1; 

void SetPinkBooleans() 
{
  for (int i = 0 ; i < 5; i++)
    pinkBooleans[i] = true;
    
  pinkBooleansSet = true;
}

///// Green Booleans /////
bool greenUp1 = true;
bool greenUp2 = true;
bool greenUp3 = true;
bool greenLeft1 = true;
bool greenLeft2 = true;
bool greenBooleans[5];
bool greenBooleansSet = false;
float greenEnemySpeed = 0.1; 

void SetGreenBooleans()
{
  for (int i = 0 ; i < 5; i++)
    greenBooleans[i] = true;
    
  greenBooleansSet = true;
}

Text helpDescription;
Text gameOverText;
Text gameOverText2; 
Text gameWinText;
Text gameWinText2;
Text gameWinText3;

int gameState = 0;

Sprite redEnemy;
Sprite pinkEnemy;
Sprite greenEnemy;
Sprite blueEnemy;

bool ghostsSet = false;
bool ghostsRespawned = false;
bool correctGhostRestart = false;

Texture redTexture;
Texture pinkTexture;
Texture greenTexture;
Texture blueTexture;

//////////---------- FUNCTIONS ----------//////////

void ResetBooleans()
{

  //for (int i = 0; i < numberOfPowerPellets; i++)
  //{
    //powerPelletsEaten[i] = false; 
  //}

  life1.setScale(0.07, 0.07);
  life1.setPosition(50, 840); 
  
  life2.setScale(0.07, 0.07);
  life2.setPosition(90, 840);

  life3.setScale(0.07, 0.07); 
  life3.setPosition(130, 840);

  redEnemy.setPosition(300, 450);
  pinkEnemy.setPosition(325, 450);
  greenEnemy.setPosition(350, 450);
  blueEnemy.setPosition(375, 450);

  blueUp = true;
  blueRight = true;
  blueDown = true;
  
  for(int i = 0; i < 13; i++)
    blueBooleans[i] = true;

  redUp = true;
  redRight = true;
  redDown = true;
  
  for (int i = 0; i < 13; i++)
    redBooleans[i] = true;

  pinkUp1 = true;
  pinkUp2 = true;
  pinkUp3 = true;
  pinkLeft1 = true;
  pinkLeft2 = true;
  
  for (int i = 0; i < 5; i++)
    pinkBooleans[i] = true;

  greenUp1 = true;
  greenUp2 = true;
  greenUp3 = true;
  greenLeft1 = true;
  greenLeft2 = true;
  
  for (int i = 0; i < 5; i++)
    greenBooleans[i] = true;
}

void SetGhosts()
{
    if (!redTexture.loadFromFile("Graphics/Red Enemy.png"))
    {
        cout << "Red Enemy not loaded correctly" << endl;
    }
    
    if (!pinkTexture.loadFromFile("Graphics/Pink Enemy.png"))
    {
        cout << "Pink Enemy not loaded correctly" << endl;
    }

    
    if (!greenTexture.loadFromFile("Graphics/Green Enemy.png"))
    {
        cout << "Green Enemy not loaded correctly" << endl;
    }
    
    if (!blueTexture.loadFromFile("Graphics/Blue Enemy.png"))
    {
        cout << "Blue Enemy not loaded correctly" << endl;
    }

    redEnemy.setTexture(redTexture);
    redEnemy.setPosition(300, 450);
    redEnemy.setScale(0.25, 0.25);
    
    pinkEnemy.setTexture(pinkTexture);
    pinkEnemy.setPosition(325, 450); 
    pinkEnemy.setScale(0.25, 0.25);
    
    greenEnemy.setTexture(greenTexture);
    greenEnemy.setPosition(350, 450);
    greenEnemy.setScale(0.25, 0.25);
    
    blueEnemy.setTexture(blueTexture);
    blueEnemy.setPosition(375, 450); 
    blueEnemy.setScale(0.25, 0.25);
    
    ghostsSet = true;
}

void GreenEnemyMovement(Sprite& greenEnemy) // Loop (X = 25, Y = 100, X = 300, Y = 200, X = 225)
{
  bool greenLoopBooleans[5];
  
  for (int i = 0; i < 5; i++)
    greenLoopBooleans[i] = true;

  if (!greenBooleansSet)
    SetGreenBooleans();
    
  if (greenUp1)
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x, greenEnemy.getPosition().y - greenEnemySpeed);
    if (greenEnemy.getPosition().y <= 350)
    {
      greenUp1 = false;
    }
  }
  
  if (greenLeft1 && !greenUp1)
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x + greenEnemySpeed, greenEnemy.getPosition().y);
    if (greenEnemy.getPosition().x >= 400)
    {
      greenLeft1 = false;
    }
  }
  
  if (!greenLeft1 && greenUp2)
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x, greenEnemy.getPosition().y - greenEnemySpeed);
    if (greenEnemy.getPosition().y <= 275)
    {
      greenUp2 = false;
    }
  }
  
  if (greenLeft2 && !greenUp2)
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x + greenEnemySpeed, greenEnemy.getPosition().y);
    if (greenEnemy.getPosition().x >= 450)
    {
      greenLeft2 = false;
    }
  }
  
  if (!greenLeft2 && greenUp3)
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x, greenEnemy.getPosition().y - greenEnemySpeed);
    if (greenEnemy.getPosition().y <= 200)
    {
      greenUp3 = false;
    }
  }
  
  /////---------- In Loop ----------//////////
  
  if (greenBooleans[0] && !greenUp3)
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x - greenEnemySpeed, greenEnemy.getPosition().y);
    if (greenEnemy.getPosition().x <= 375)
    {
      greenBooleans[0] = false;
    }
  }
  
  if (greenBooleans[1] && !greenBooleans[0])
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x, greenEnemy.getPosition().y - greenEnemySpeed);
    if (greenEnemy.getPosition().y <= 100)
    {
      greenBooleans[1] = false;
    }
  }
  
  if (greenBooleans[2] && !greenBooleans[1])
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x + greenEnemySpeed, greenEnemy.getPosition().y);
    if (greenEnemy.getPosition().x >= 650)
    {
      greenBooleans[2] = false;
    }
  }
  
  if (greenBooleans[3] && !greenBooleans[2])
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x, greenEnemy.getPosition().y + greenEnemySpeed);
    if (greenEnemy.getPosition().y >= 200)
    {
      greenBooleans[3] = false;
    }
  }
  
  if (greenBooleans[4] && !greenBooleans[3])
  {
    greenEnemy.setPosition(greenEnemy.getPosition().x - greenEnemySpeed, greenEnemy.getPosition().y);
    if (greenEnemy.getPosition().x >= 575)
    {
      greenBooleans[4] = false;
      for (int i = 0; i < 5; i++)
      {
        greenBooleans[i] = true;
      }
    }
  }
}

int pacmanMaze[MAP_HEIGHT][MAP_WIDTH] = 
{
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1},
    {1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 1, 0, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 3, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {2, 2, 2, 2, 1, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2},
    {1, 1, 1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 0, 1, 1, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1},
    {1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1},
    {1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1},
    {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
    {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
    {1, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
    {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}
};

void PinkEnemyMovement(Sprite& pinkEnemy) // Loop (X = 25, Y = 100, X = 300, Y = 200, X = 225)
{
  bool pinkLoopBooleans[5];
  
  for (int i = 0; i < 5; i++)
    pinkLoopBooleans[i] = true;

  if (!pinkBooleansSet)
    SetPinkBooleans();
    
  if (pinkUp1)
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x, pinkEnemy.getPosition().y - pinkEnemySpeed);
    if (pinkEnemy.getPosition().y <= 350)
    {
      pinkUp1 = false;
    }
  }
  
  if (pinkLeft1 && !pinkUp1)
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x - pinkEnemySpeed, pinkEnemy.getPosition().y);
    if (pinkEnemy.getPosition().x <= 290)
    {
      pinkLeft1 = false;
    }
  }
  
  if (!pinkLeft1 && pinkUp2)
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x, pinkEnemy.getPosition().y - pinkEnemySpeed);
    if (pinkEnemy.getPosition().y <= 275)
    {
      pinkUp2 = false;
    }
  }
  
  if (pinkLeft2 && !pinkUp2)
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x - pinkEnemySpeed, pinkEnemy.getPosition().y);
    if (pinkEnemy.getPosition().x <= 225)
    {
      pinkLeft2 = false;
    }
  }
  
  if (!pinkLeft2 && pinkUp3)
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x, pinkEnemy.getPosition().y - pinkEnemySpeed);
    if (pinkEnemy.getPosition().y <= 200)
    {
      pinkUp3 = false;
    }
  }
  
  /////---------- In Loop ----------//////////
  
  if (pinkBooleans[0] && !pinkUp3)
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x - pinkEnemySpeed, pinkEnemy.getPosition().y);
    if (pinkEnemy.getPosition().x <= 25)
    {
      pinkBooleans[0] = false;
    }
  }
  
  if (pinkBooleans[1] && !pinkBooleans[0])
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x, pinkEnemy.getPosition().y - pinkEnemySpeed);
    if (pinkEnemy.getPosition().y <= 100)
    {
      pinkBooleans[1] = false;
    }
  }
  
  if (pinkBooleans[2] && !pinkBooleans[1])
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x + pinkEnemySpeed, pinkEnemy.getPosition().y);
    if (pinkEnemy.getPosition().x >= 300)
    {
      pinkBooleans[2] = false;
    }
  }
  
  if (pinkBooleans[3] && !pinkBooleans[2])
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x, pinkEnemy.getPosition().y + pinkEnemySpeed);
    if (pinkEnemy.getPosition().y >= 200)
    {
      pinkBooleans[3] = false;
    }
  }
  
  if (pinkBooleans[4] && !pinkBooleans[3])
  {
    pinkEnemy.setPosition(pinkEnemy.getPosition().x - pinkEnemySpeed, pinkEnemy.getPosition().y);
    if (pinkEnemy.getPosition().x >= 225)
    {
      pinkBooleans[4] = false;
      for (int i = 0; i < 5; i++)
      {
        pinkBooleans[i] = true;
      }
    }
  }
}

void RedEnemyMovement(Sprite& redEnemy) 
{
  bool movingUp = true;
  bool movingRight = true;
  bool movingDown = true;
  
  bool redLoopBooleans[13];
  
  for (int i = 0; i < 13; i++)
    redLoopBooleans[i] = true;

  if (!redBooleansSet)
    SetRedBooleans();
  
  if (movingUp && redUp)
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y - redEnemySpeed);
    if (redEnemy.getPosition().y <= 360)
    {
      movingUp = false;
      redUp = false;
    }
  }
  
  if (!redUp && movingRight && redRight)
  {
    redEnemy.setPosition(redEnemy.getPosition().x - redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x <= 210)
    {
      movingRight = false;
      redRight = false;
    }
  }
  
  if (!redRight && movingDown && redDown)
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y + redEnemySpeed);
    if (redEnemy.getPosition().y >= 600)
    {
      movingDown = false;
      redDown = false;
    }
  }
  
/////---------- Loop Coding ----------/////
  
  if (!redDown && redLoopBooleans[0] && redBooleans[0])
  {
    redEnemy.setPosition(redEnemy.getPosition().x + redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x >= 300)
    {
      redBooleans[0] = false;
    }
  }
  
  if (!redBooleans[0] && redLoopBooleans[1] && redBooleans[1])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y + redEnemySpeed);
    if (redEnemy.getPosition().y >= 650)
    {
      redBooleans[1] = false;
    }
  }
  
  if (!redBooleans[1] && redLoopBooleans[2] && redBooleans[2])
  {
    redEnemy.setPosition(redEnemy.getPosition().x - redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x <= 225)
    {
      redBooleans[2] = false;
    }
  }
  
  if (!redBooleans[2] && redLoopBooleans[3] && redBooleans[3])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y + redEnemySpeed);
    if (redEnemy.getPosition().y >= 700)
    {
      redBooleans[3] = false;
    }
  }
  
  if (!redBooleans[3] && redLoopBooleans[4] && redBooleans[4])
  {
    redEnemy.setPosition(redEnemy.getPosition().x + redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x >= 300)
    {
      redBooleans[4] = false;
    }
  }
  
  if (!redBooleans[4] && redLoopBooleans[5] && redBooleans[5])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y + redEnemySpeed);
    if (redEnemy.getPosition().y >= 775)
    {
      redBooleans[5] = false;
    }
  }
  
  if (!redBooleans[5] && redLoopBooleans[6] && redBooleans[6])
  {
    redEnemy.setPosition(redEnemy.getPosition().x - redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x <= 25)
    {
      redBooleans[6] = false;
    }
  }
  
  if (!redBooleans[6] && redLoopBooleans[7] && redBooleans[7])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y - redEnemySpeed);
    if (redEnemy.getPosition().y <= 700)
    {
      redBooleans[7] = false;
    }
  }
  
  if (!redBooleans[7] && redLoopBooleans[8] && redBooleans[8])
  {
    redEnemy.setPosition(redEnemy.getPosition().x + redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x >= 75)
    {
      redBooleans[8] = false;
    }
  }
  
  if (!redBooleans[8] && redLoopBooleans[9] && redBooleans[9])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y - redEnemySpeed);
    if (redEnemy.getPosition().y <= 650)
    {
      redBooleans[9] = false;
    }
  }
  
  if (!redBooleans[9] && redLoopBooleans[10] && redBooleans[10])
  {
    redEnemy.setPosition(redEnemy.getPosition().x - redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x <= 25)
    {
      redBooleans[10] = false;
    }
  }
  
  if (!redBooleans[10] && redLoopBooleans[11] && redBooleans[11])
  {
    redEnemy.setPosition(redEnemy.getPosition().x, redEnemy.getPosition().y - redEnemySpeed);
    if (redEnemy.getPosition().y <= 600)
    {
      redBooleans[11] = false;
    }
  }
  
  if (!redBooleans[11] && redLoopBooleans[12] && redBooleans[12])
  {
    redEnemy.setPosition(redEnemy.getPosition().x + redEnemySpeed, redEnemy.getPosition().y);
    if (redEnemy.getPosition().x >= 110) 
    {
      redBooleans[12] = false;
      for (int i = 0; i < 13; i++)
      {
        redLoopBooleans[i] = true;
        redBooleans[i] = true;
      }
    }
  }
}

void setPellets()
{
  for (int i = 0; i < numberOfPellets; i++)
  {
    drawPellets[i] = true;
  }
  
  for (int i = 0; i < numberOfPellets; i++)
  {
    pellets[i].setSize(Vector2f(4, 4));
    pellets[i].setFillColor(Color::White);
  }
}

void setPowerPellets()
{
  for (int i = 0; i < numberOfPowerPellets; i++)
  {
    powerPelletsEaten[i] = false;
  }
  
  for (int i = 0; i < numberOfPowerPellets; i++)
  {
    powerPellets[i].setRadius(9.0f);
    powerPellets[i].setFillColor(Color(128, 128, 128));
  }
}

bool isIntersecting(const Sprite& player, const RectangleShape& pellet)
{
    return player.getGlobalBounds().intersects(pellet.getGlobalBounds());
}

bool isIntersecting(const Sprite& player, const CircleShape& pellet)
{
    return player.getGlobalBounds().intersects(pellet.getGlobalBounds());
}

bool collidingWithPowerPellet(const Sprite& player, const CircleShape& powerPellet)
{
    return player.getGlobalBounds().intersects(powerPellet.getGlobalBounds());
}

bool EnemyCollision(const Sprite& player, const Sprite& enemy)
{
  return player.getGlobalBounds().intersects(enemy.getGlobalBounds());
}

// Loop (X = 650, Y = 650, X = 600, Y = 700, X = 650, Y = 775, X = 375, Y = 700, X = 450, Y = 650, X = 375, Y = 600, X = 460) 

void BlueEnemyMovement(Sprite& blueEnemy) 
{
  bool movingUp = true;
  bool movingRight = true;
  bool movingDown = true;
  
  bool blueLoopBooleans[13];
  
  for (int i = 0; i < 13; i++)
    blueLoopBooleans[i] = true;

  if (!blueBooleansSet)
    SetBlueBooleans();
  
  if (movingUp && blueUp)
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y - blueEnemySpeed);
    if (blueEnemy.getPosition().y <= 360)
    {
      movingUp = false;
      blueUp = false;
    }
  }
  
  if (!blueUp && movingRight && blueRight)
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x >= 460)
    {
      movingRight = false;
      blueRight = false;
    }
  }
  
  if (!blueRight && movingDown && blueDown)
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y + blueEnemySpeed);
    if (blueEnemy.getPosition().y >= 600)
    {
      movingDown = false;
      blueDown = false;
    }
  }
  
/////---------- Loop Coding ----------/////
  
  if (!blueDown && blueLoopBooleans[0] && blueBooleans[0])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x >= 650)
    {
      blueBooleans[0] = false;
    }
  }
  
  if (!blueBooleans[0] && blueLoopBooleans[1] && blueBooleans[1])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y + blueEnemySpeed);
    if (blueEnemy.getPosition().y >= 650)
    {
      blueBooleans[1] = false;
    }
  }
  
  if (!blueBooleans[1] && blueLoopBooleans[2] && blueBooleans[2])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x - blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x <= 600)
    {
      blueBooleans[2] = false;
    }
  }
  
  if (!blueBooleans[2] && blueLoopBooleans[3] && blueBooleans[3])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y + blueEnemySpeed);
    if (blueEnemy.getPosition().y >= 700)
    {
      blueBooleans[3] = false;
    }
  }
  
  if (!blueBooleans[3] && blueLoopBooleans[4] && blueBooleans[4])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x >= 650)
    {
      blueBooleans[4] = false;
    }
  }
  
  if (!blueBooleans[4] && blueLoopBooleans[5] && blueBooleans[5])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y + blueEnemySpeed);
    if (blueEnemy.getPosition().y >= 775)
    {
      blueBooleans[5] = false;
    }
  }
  
  if (!blueBooleans[5] && blueLoopBooleans[6] && blueBooleans[6])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x - blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x <= 375)
    {
      blueBooleans[6] = false;
    }
  }
  
  if (!blueBooleans[6] && blueLoopBooleans[7] && blueBooleans[7])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y - blueEnemySpeed);
    if (blueEnemy.getPosition().y <= 700)
    {
      blueBooleans[7] = false;
    }
  }
  
  if (!blueBooleans[7] && blueLoopBooleans[8] && blueBooleans[8])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x >= 450)
    {
      blueBooleans[8] = false;
    }
  }
  
  if (!blueBooleans[8] && blueLoopBooleans[9] && blueBooleans[9])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y - blueEnemySpeed);
    if (blueEnemy.getPosition().y <= 650)
    {
      blueBooleans[9] = false;
    }
  }
  
  if (!blueBooleans[9] && blueLoopBooleans[10] && blueBooleans[10])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x - blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x <= 375)
    {
      blueBooleans[10] = false;
    }
  }
  
  if (!blueBooleans[10] && blueLoopBooleans[11] && blueBooleans[11])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x, blueEnemy.getPosition().y - blueEnemySpeed);
    if (blueEnemy.getPosition().y <= 600)
    {
      blueBooleans[11] = false;
    }
  }
  
  if (!blueBooleans[11] && blueLoopBooleans[12] && blueBooleans[12])
  {
    blueEnemy.setPosition(blueEnemy.getPosition().x + blueEnemySpeed, blueEnemy.getPosition().y);
    if (blueEnemy.getPosition().x >= 460)
    {
      blueBooleans[12] = false;
      for (int i = 0; i < 13; i++)
      {
        blueLoopBooleans[i] = true;
        blueBooleans[i] = true;
      }
    }
  }
}

void drawMap(RenderWindow& window, Sprite& player)
{
    RectangleShape blank(Vector2f(CELL_SIZE, CELL_SIZE));
    blank.setFillColor(Color::Black);
    
    int count = 0;
    int index = 0;
    int powerCount = 0;
    
    for (int i = 0; i < numberOfWalls; i++)
    {
        walls[i].setSize(Vector2f(CELL_SIZE, CELL_SIZE));
        walls[i].setFillColor(Color::Blue);
    }

    for (int i = 0; i < MAP_HEIGHT; ++i)
    {
        for (int j = 0; j < MAP_WIDTH; ++j)
        {
            if (pacmanMaze[i][j] == 1)
            {
                walls[count].setPosition(j * CELL_SIZE, i * CELL_SIZE);
                window.draw(walls[count]);
                count++;
                
            }
            else if (pacmanMaze[i][j] == 0)
            {
                if (drawPellets[index] == true)
                {
                  pellets[index].setPosition(pelletPositionX[index], pelletPositionY[index]);
                  
                  if (tracker < numberOfPellets)
                  {
                    pelletPositionX[tracker] = j * CELL_SIZE + CELL_SIZE / 2 - 2;
                    pelletPositionY[tracker] = i * CELL_SIZE + CELL_SIZE / 2 - 2;
                    tempPelletX[tracker] = j * CELL_SIZE + CELL_SIZE / 2 - 2;
                    tempPelletY[tracker] = i * CELL_SIZE + CELL_SIZE / 2 - 2;
                  }
                  window.draw(pellets[index]);
                  tracker++;
                  index++;
                }
            }
            else if (pacmanMaze[i][j] == 2)
            {
                blank.setPosition(j * CELL_SIZE + CELL_SIZE / 2 - 2, i * CELL_SIZE + CELL_SIZE / 2 - 2);
                window.draw(blank);
            }
            
            else if (pacmanMaze[i][j] == 3)
            {
                if (powerPelletsEaten[powerCount] == false)
                {
                  powerPellets[powerCount].setPosition(j * CELL_SIZE + CELL_SIZE / 2 - 2, i * CELL_SIZE + CELL_SIZE / 2 - 2);
                  powerPellets[powerCount].setPosition(powerPellets[powerCount].getPosition().x - 5, powerPellets[powerCount].getPosition().y - 7.5f);
                  window.draw(powerPellets[powerCount]);
                }
                powerCount++;
            }
        }
    }
}

void powerPelletCheck(float& movementSpeed, Clock& clock)
{
    static float actionInterval = 10.0f; // Perform action every 5 seconds
    static bool resetClock = true;
    movementSpeed = 0.4f;
    float elapsedTime = 0;

    //cout << movementSpeed << endl; 

    // Get elapsed time in seconds
    elapsedTime = clock.getElapsedTime().asSeconds();

    cout << elapsedTime << endl;

    // Check if the action interval has passed
    if (elapsedTime >= actionInterval)
    {
        movementSpeed = 0.2f; // Change movement speed 

        // Reset the clock and elapsed time
        //clock.restart();
        //resetClock = true;
        powerPelletCollected = false;
    }
    else if (resetClock)
    {
        // Reset the clock only once after the interval has passed
        clock.restart();
        resetClock = false;
    }
}



void PlayerMove(Sprite& player, RenderWindow& window, Sprite& redEnemy, Sprite& pinkEnemy, Sprite& greenEnemy, Sprite& blueEnemy)
{ 
    RectangleShape blank(Vector2f(CELL_SIZE, CELL_SIZE));
    blank.setFillColor(Color::Black);
    
    //cout << movementSpeed << endl; 
    
    if (score >= 250)
    {
      gameState = 4;
    }
    
    for (int i = 0; i < numberOfPowerPellets; i++)
    {
      if (isIntersecting(player, powerPellets[i]))
      {
        if (powerPelletsEaten[i] == false && !powerPelletCollected)
        {
          score += 5;
          scoreText.setString("score: " + to_string(score));
          powerPellets[i].setFillColor(Color::Black); 
          powerPelletsEaten[i] = true;
          powerPelletCollected = true; 
          loopEntered = true;
          break;
        }
      }
    }
    
    if (!powerPelletCollected)
    {
      if (EnemyCollision(player, redEnemy) || EnemyCollision(player, blueEnemy) || EnemyCollision(player, pinkEnemy) || EnemyCollision(player, greenEnemy))
      {
        if (lives == 3)
        {
          life1.setPosition(-1000, -1000);
        }
        else if (lives == 2)
        {
          life2.setPosition(-1000, -1000);
        }
        else if (lives == 1)
        {
          life3.setPosition(-1000, -1000);
        }
    
        lives--;
        player.setPosition(100, 450);
        //sleep(milliseconds(500));
        
        if (lives <= 0)
        {
          gameState = 3;
        }
      }
    }
    else
    {
      if (EnemyCollision(player, redEnemy))
      {
        redEnemy.setPosition(300, 450);
        redUp = true;
        redRight = true;
        redDown = true;
        
        for (int i = 0; i < 13; i++)
        {
          redBooleans[i] = true;
        }
      }
      
      if (EnemyCollision(player, pinkEnemy))
      {
        pinkEnemy.setPosition(325, 450);
        pinkUp1 = true;
        pinkUp2 = true;
        pinkUp3 = true;
        pinkLeft1 = true;
        pinkLeft2 = true;
        for (int i = 0; i < 5; i++)
          pinkBooleans[i] = true;
        
      }
      
      if (EnemyCollision(player, greenEnemy))
      {
        greenEnemy.setPosition(350, 450); 
        greenUp1 = true;
        greenUp2 = true;
        greenUp3 = true;
        greenLeft1 = true;
        greenLeft2 = true;
        for (int i = 0; i < 5; i++)
          greenBooleans[i] = true;
      }
      
      if (EnemyCollision(player, blueEnemy))
      {
        blueEnemy.setPosition(375, 450);
        blueUp = true;
        blueRight = true;
        blueDown = true;
        for (int i = 0; i < 13; i++)
          blueBooleans[i] = true;
      }
    }
    

    
    for (int i = 0; i < numberOfPellets; i++)
    {
      if (isIntersecting(player, pellets[i]))
      { 
        for (int j = 0; j < numberOfPellets; j++)
        {
          if (pellets[i].getPosition().x == pelletPositionX[j] && pellets[i].getPosition().y == pelletPositionY[j])
          {
            pelletPositionX[j] = -1000;
            pelletPositionY[j] = -1000;
            break;
          }
        }
        
        score += 1;
        scoreText.setString("score: " + to_string(score)); 
        break;
      }    
    }

    if (Keyboard::isKeyPressed(Keyboard::Left))
    {
        player.move(-movementSpeed, 0);
        for (int i = 0; i < numberOfWalls; i++)
        {
          if (isIntersecting(player, walls[i]))
          {
	    player.move(movementSpeed, 0);
          }
        }
    }
    if (Keyboard::isKeyPressed(Keyboard::Right))
    {
        player.move(movementSpeed, 0);
        for (int i = 0; i < numberOfWalls; i++)
        {
          if (isIntersecting(player, walls[i]))
          {
	    player.move(-movementSpeed, 0);
          }
        }
    }
    if (Keyboard::isKeyPressed(Keyboard::Up))
    {
        player.move(0, -movementSpeed);
        for (int i = 0; i < numberOfWalls; i++)
        {
          if (isIntersecting(player, walls[i]))
          {
	    player.move(0, movementSpeed);
          }
        }
    }
    if (Keyboard::isKeyPressed(Keyboard::Down))
    {
        player.move(0, movementSpeed);
        for (int i = 0; i < numberOfWalls; i++)
        {
          if (isIntersecting(player, walls[i]))
          {
	    player.move(0, -movementSpeed);
          }
        }
    }
}


void* StartGame(void* arg)
{
    lives = 3;
    powerPelletCollected = false;
    //int gameState = 0;
    int select = 0;
    Clock clock;

    RenderWindow window(VideoMode(MAP_WIDTH * CELL_SIZE, MAP_HEIGHT * CELL_SIZE), "Pac-Man Game"); // 700 x 900
    
    Texture playerTexture;
    if (!playerTexture.loadFromFile("Graphics/player.png"))
    {
        cout << "Could not load player sprite" << endl;
    }
    
    Sprite player(playerTexture);
    player.setPosition(100, 450);
    player.setScale(0.045, 0.045);
    


    if (!setPellet)
    {
      setPellets();
      setPellet = true; 
    }
    
    if (!setPowerPellet)
    {
      setPowerPellets();
      setPowerPellet = true;
    }

    Text playText;
    Text helpText;
    Text exitText;
  
    playText.setFont(pixelFont);
    playText.setCharacterSize(30);
    playText.setFillColor(Color::Green);
    playText.setPosition(300, 300);
    playText.setString("PLAY");
    
    helpText.setFont(pixelFont);
    helpText.setCharacterSize(30);
    helpText.setFillColor(Color::Green);
    helpText.setPosition(300, 400);
    helpText.setString("HELP");
  
    exitText.setFont(pixelFont);
    exitText.setCharacterSize(30);
    exitText.setFillColor(Color::Green);
    exitText.setPosition(300, 500);
    exitText.setString("EXIT");
    
    helpDescription.setFont(pixelFont);
    helpDescription.setCharacterSize(16);
    helpDescription.setFillColor(Color::White);
    helpDescription.setPosition(0, 0);
    helpDescription.setString("\n\n\n Its just as simple as collecting pellets \n\n and dodging ghosts!\n\n\n\n But watch out for the faster ghosts who \n\n might get rid of you even before you \n\n realize!\n\n\n\n But don't worry, there's some good news \n\n too. The power pellets can help you gain \n\n speed  and eat those ghosts \n\n\n\n Have Fun!\n\n\n\n          PRESS ENTER TO GO BACK");
    
    gameOverText.setFont(pixelFont);
    gameOverText.setCharacterSize(25);
    gameOverText.setFillColor(Color::Blue);
    gameOverText.setPosition(200, 350);
    gameOverText.setString("GAME OVER!");
    
    gameOverText2.setFont(pixelFont);
    gameOverText2.setCharacterSize(25);
    gameOverText2.setFillColor(Color::Blue);
    gameOverText2.setPosition(75, 450);
    gameOverText2.setString("PRESS ENTER TO RESTART");

    
    gameWinText.setFont(pixelFont);
    gameWinText.setCharacterSize(30);
    gameWinText.setFillColor(Color::Blue);
    gameWinText.setPosition(100, 200);
    gameWinText.setString("CONGRATULATIONS!");
    
    gameWinText2.setFont(pixelFont);
    gameWinText2.setCharacterSize(20);
    gameWinText2.setFillColor(Color::Yellow);
    gameWinText2.setPosition(175, 400); 
    gameWinText2.setString("You Won the Game!");
    
    gameWinText3.setFont(pixelFont);
    gameWinText3.setCharacterSize(25);
    gameWinText3.setFillColor(Color::Red);
    gameWinText3.setPosition(75, 600);
    gameWinText3.setString("Press Enter to Return");

    if (!logoTexture.loadFromFile("Graphics/Logo"))
    {
      cout << "Logo not loaded correctly" << endl;
    }

    Sprite menuLogo;
    menuLogo.setTexture(logoTexture);
    menuLogo.setScale(0.075, 0.075);
    menuLogo.setPosition(200, 0);
    
    Sprite arrow;
    Texture arrowTexture;
    
    if (!arrowTexture.loadFromFile("Graphics/Arrow 3.png"))
    {
      cout << "Arrow not loaded correctly" << endl;
    }
    
    arrow.setTexture(arrowTexture);
    arrow.setScale(0.1, 0.1);
    arrow.setPosition(225, 290);
    
    if(!ghostsSet)
    {
      SetGhosts();
    }
    
    while (window.isOpen())
    {
    
      float time = clock.getElapsedTime().asSeconds(); 
      clock.restart();
      
      if (powerPelletCollected)
      {
        movementSpeed = 0.4;
        timer += time;
        if (timer >= 5)
        {
          movementSpeed = 0.2;
          timer = 0;
          powerPelletCollected = false;
        }
      }
    
      if (gameState == 0)
      {
        lives = 3;
        score = 0;
        ghostsRespawned = false;
      
        if (select == 0)
        {
          arrow.setPosition(225, 290);
        }
        else if (select == 1)
        {
          arrow.setPosition(225, 390);
        }
        else if (select == 2)
        {
          arrow.setPosition(225, 490);
        }
      
        Event selectController;
        while (window.pollEvent(selectController))
        {

          if (selectController.type == Event::KeyPressed)
          {
            if (selectController.key.code == Keyboard::Up)
            {
              if (select == 1)
              {
                select = 0;
              }
              else if (select == 2)
              {
                select = 1;
              }
            }
            
            if (selectController.key.code == Keyboard::Down)
            {
              if (select == 0)
              {
                select = 1;
              }
              else if (select == 1)
              {
                select = 2;
              }
            }
            
            if (selectController.key.code == Keyboard::Enter)
            {
              if (select == 0)
              {
                gameState = 1;
              }
              else if (select == 1)
              {
                gameState = 2;
              }
              else if (select == 2)
              {
                window.close();
              }
            }
          }
        }
      
        window.clear(Color::Black);
      
        window.draw(playText);
        window.draw(helpText);
        window.draw(exitText);
        window.draw(menuLogo);
        window.draw(arrow);
        
        window.display();
      }
      else if (gameState == 1)
      {
        if (!ghostsRespawned)
        {
          ResetBooleans();
          ghostsRespawned = true;
        }
        
      
        BlueEnemyMovement(blueEnemy);
        RedEnemyMovement(redEnemy); 
        PinkEnemyMovement(pinkEnemy); 
        GreenEnemyMovement(greenEnemy);
      
        Event event;
        while (window.pollEvent(event))
        {
          if (event.type == Event::Closed)
            window.close();
        }

	PlayerMove(player, window, redEnemy, pinkEnemy, greenEnemy, blueEnemy);

        window.clear(Color::Black);

        drawMap(window, player);
        window.draw(player);
        window.draw(redEnemy);
        window.draw(pinkEnemy);
        window.draw(greenEnemy);
        window.draw(blueEnemy);
        window.draw(scoreText);
        window.draw(highScoreText);
        window.draw(logo);
        window.draw(life1);
        window.draw(life2);
        window.draw(life3);
        
        window.display();
      }
      else if (gameState == 2) // HELP
      {
      
        Event selectController;
        while (window.pollEvent(selectController))
        {
          if (selectController.type == Event::KeyPressed)
          {
            if (selectController.key.code == Keyboard::Enter)
            {
              gameState = 0;
            }
          }
        }
        
        window.clear(Color::Black);
        window.draw(helpDescription); 
        window.display();
      }
      else if (gameState == 3) // Game Over
      {
        player.setPosition(100, 450);
        setPowerPellets();
        score = 0;
        lives = 3;
        Event selectController;
        while (window.pollEvent(selectController))
        {
          if (selectController.type == Event::KeyPressed)
          {
            if (selectController.key.code == Keyboard::Enter)
            {
              
              //if (!correctGhostRestart)
              //{
                ResetBooleans();
                //correctGhostRestart = true;
              //}
              
              for (int i = 0; i < numberOfPellets; i++)
              {
                pelletPositionX[i] = tempPelletX[i];
                pelletPositionY[i] = tempPelletY[i];
              }
              
              gameState = 1;
            }
          }
        }
      
        window.clear(Color::Black);
        window.draw(gameOverText);
        window.draw(gameOverText2);
        window.display();
      
      }
      else if (gameState == 4) // Game Won
      {
        player.setPosition(100, 450);
        setPowerPellets();
        lives = 3;
        for (int i = 0; i < numberOfPellets; i++)
        {
          pelletPositionX[i] = tempPelletX[i];
          pelletPositionY[i] = tempPelletY[i];
        }
      
        Event selectController;
        while (window.pollEvent(selectController))
        {
          if (selectController.type == Event::KeyPressed)
          {
            if (selectController.key.code == Keyboard::Enter)
            {
              gameState = 0;
            }
          }
        }
      
        window.clear(Color::Black);
        window.draw(gameWinText);
        window.draw(gameWinText2);
        window.draw(gameWinText3);
        window.display();
      }
    }
    
    pthread_exit(NULL);
}

void* SetupUI(void* arg)
{  
  if (!scoreFont.loadFromFile("Graphics/ScoreFont.ttf"))
  {
    cout << "Score Font not loaded correctly" << endl;
  }
  
  if (!logoTexture.loadFromFile("Graphics/Logo"))
  {
    cout << "Logo not loaded correctly" << endl;
  }
  
  if (!pacmanFont.loadFromFile("Graphics/pacman.ttf"))
  {
    cout << "Pacman Font not loaded correctly" << endl;
  }
  
  if (!pixelFont.loadFromFile("Graphics/pixel.ttf"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  
  if (!life1Texture.loadFromFile("Graphics/life.png"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  
  if (!life2Texture.loadFromFile("Graphics/life.png"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  
  if (!life3Texture.loadFromFile("Graphics/life.png"))
  {
    cout << "Pixel Font not loaded correctly" << endl;
  }
  
  logo.setTexture(logoTexture);
  logo.setScale(0.05, 0.05);
  logo.setPosition(250, -15);
  
  scoreText.setFont(pixelFont);
  scoreText.setCharacterSize(13);
  scoreText.setFillColor(Color::White);
  scoreText.setPosition(30, 25);
  scoreText.setString("score: " + to_string(score));
  
  highScoreText.setFont(pixelFont);
  highScoreText.setCharacterSize(13);
  highScoreText.setFillColor(Color::White);
  highScoreText.setPosition(500, 25);
  highScoreText.setString("high score: " + to_string(highScore));

  
  life1.setTexture(life1Texture);
  life2.setTexture(life2Texture);
  life3.setTexture(life3Texture);
  
  life1.setScale(0.07, 0.07);
  life1.setPosition(50, 840);
  
  life2.setScale(0.07, 0.07);
  life2.setPosition(90, 840);

  life3.setScale(0.07, 0.07); 
  life3.setPosition(130, 840);
  
  pthread_exit(NULL);
}

int main()
{
    pthread_t gameEngineThread;
    pthread_create(&gameEngineThread, NULL, StartGame, NULL);
    
    pthread_t userInterfaceThread;
    pthread_create(&userInterfaceThread, NULL, SetupUI, NULL);

    pthread_exit(NULL);

    return 0;
}
